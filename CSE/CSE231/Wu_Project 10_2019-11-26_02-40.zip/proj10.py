"""
   Computer Project #10
   This assignment focuses on the design, implementation and testing of a Python program which
   uses an instructor-supplied module to play a card game, as described below.
   Aces Up is a popular solitaire card game which is played by one person with a standard 52-card
   deck of cards. 
"""


import cards  # required !!!

RULES = '''
Aces High Card Game:
     Tableau columns are numbered 1,2,3,4.
     Only the card at the bottom of a Tableau column can be moved.
     A card can be moved to the Foundation only if a higher ranked card 
        of the same suit is at the bottom of another Tableau column.
     To win, all cards except aces must be in the Foundation.'''

MENU = '''     
Input options:
    D: Deal to the Tableau (one card on each column).
    F x: Move card from Tableau column x to the Foundation.
    T x y: Move card from Tableau column x to empty Tableau column y.
    R: Restart the game (after shuffling)
    H: Display the menu of choices
    Q: Quit the game        
'''
def init_game():
             
    stock = cards.Deck()
    stock.shuffle()
    
    foundation = []
    tableau = [ [] , [] , [] , [] ]
    deal_to_tableau( stock, tableau )
    
    return (stock, tableau, foundation)  # stub so that the skeleton compiles; delete 
                               # and replace it with your code
    
def deal_to_tableau( stock, tableau ):
        
    for i in range(0,4):
        tableau[i].append(stock.deal())
 
    
    pass  # stub; delete and replace it with your code


def display( stock, tableau, foundation ):
    '''Display the stock, tableau, and foundation.'''
    
    print("\n{:<8s}{:^13s}{:s}".format( "stock", "tableau", "  foundation"))
    
    # determine the number of rows to be printed -- determined by the most
    #           cards in any tableau column
    max_rows = 0
    for col in tableau:
        if len(col) > max_rows:
            max_rows = len(col)

    for i in range(max_rows):
        # display stock (only in first row)
        if i == 0:
            display_char = "" if stock.is_empty() else "XX"
            print("{:<8s}".format(display_char),end='')
        else:
            print("{:<8s}".format(""),end='')

        # display tableau
        for col in tableau:
            if len(col) <= i:
                print("{:4s}".format(''), end='')
            else:
                print("{:4s}".format( str(col[i]) ), end='' )

        # display foundation (only in first row)
        if i == 0:
            if len(foundation) != 0:
                print("    {}".format(foundation[-1]), end='')

        print()

def get_option():
    o = input('Input an option (DFTRHQ): ')
    o1 = o.upper()
    inf = o1.split()
    #print(inf)
    
    if inf[0] not in 'DFTRHQ':
        print('Error in option: {}'.format(o))
        print('Invalid option.')
        return None
    
    if inf[0] in 'DRHQ' and len(inf) == 1: return inf
    elif inf[0] == 'F' and inf[1].isdigit() == True and len(inf) == 2: return inf
    elif inf[0] == 'T' and len(inf) == 3 and inf[1].isdigit() == True and inf[2].isdigit(): return inf
    else:
        print('Error in option:  {}'.format(o))
        print('Invalid option.')
        return None
   
    
    
    # stub; delete and replace with your code
            
def validate_move_to_foundation( tableau, from_col ):
    from_col = int(from_col)
    from_col -= 1
    if from_col not in range(0,4): return False
    
    D = dict()
    bottom = []
    for i in range(0,4):
        try:
            bottom.append(tableau[i][-1])
        except:
            bottom.append('')
    if bottom[from_col] == '': 
        print('Error, cannot move {}.'.format(bottom[from_col].__repr__()))
        return False
    #print(bottom)   
    for i in bottom:
        if i != '':
            try:
                D [i.suit()] += 1
            except:
                D [i.suit()] = 1  
        
    if D [bottom[from_col].suit()] == 1: 
        print('Error, cannot move {}.'.format(bottom[from_col].__repr__()))
        return False
   
    suit = bottom[from_col].suit()
    rank = int ( bottom[from_col].rank() )
    
    if rank == 1: 
        print('Error, cannot move {}.'.format(bottom[from_col].__repr__()))
        return False
    
    #print(suit,rank)
    for i in bottom:
        try:
            if i.suit() == suit and int(i.rank()) == 1: return True
            if i.suit() == suit and int(i.rank()) > rank: return True       
        except:
            pass
      
    print('Error, cannot move {}.'.format(bottom[from_col].__repr__()))
    return False  # stub; delete and replace it with your code   

    
def move_to_foundation( tableau, foundation, from_col ):
    from_col = int(from_col)
    if validate_move_to_foundation( tableau, from_col ):
        c = tableau[from_col-1].pop()
        foundation.append(c)
 
    pass  # stub; delete and replace it with your code   


def validate_move_within_tableau( tableau, from_col, to_col ):
    from_col = int(from_col)
    if from_col not in range(1,5) or to_col not in range(1,5): 
        print('Invalid move')
        return False
    if tableau [to_col-1] == [] and tableau [from_col-1] != []: return True
    print('Invalid move')
    return False  # stub; delete and replace it with your code



def move_within_tableau( tableau, from_col, to_col ):
    from_col = int(from_col)
    to_col = int( to_col)
    if validate_move_within_tableau( tableau, from_col, to_col ):
        c = tableau[from_col-1].pop()
        tableau [to_col-1].append(c)
 
    pass  # stub; delete and replace it with your code   

        
def check_for_win( stock, tableau ):
   
    total = 0
   # print(stock.is_empty())
    if stock.is_empty():
        for i in range(0,4):
            if len(tableau[i]) > 1: return False
            total += int ( tableau[i][0].rank() )
                

        if total == 4: return True
 
    return False  # stub; delete and replace it with your code   

        
def main():
        
    '''
        WRITE DOCSTRING HERE!!!
    '''
 
    stock, tableau, foundation = init_game()
    print( MENU )
    display( stock, tableau, foundation )
    print()

    while True:
        Inf = get_option()
        if Inf == None:
            display( stock, tableau, foundation)
            continue
        if Inf[0] == 'H': print( MENU )
        if Inf[0] == 'D': deal_to_tableau( stock, tableau )
        if Inf[0] == 'R': 
            stock, tableau, foundation = init_game()
            print('=========== Restarting: new game ============')
            print(RULES)
            print(MENU)
        if Inf[0] == 'Q': 
            print('You have chosen to quit.')
            break
        if Inf[0] == 'F': 
           move_to_foundation( tableau, foundation, Inf[1] )
                
        if Inf[0] == 'T':
            move_within_tableau( tableau, Inf[1] , Inf[2] )
        # Your code goes here
        if check_for_win( stock, tableau ):
            print('You won!')
            break
        display( stock, tableau, foundation)
        print()

if __name__ == "__main__":
    main()