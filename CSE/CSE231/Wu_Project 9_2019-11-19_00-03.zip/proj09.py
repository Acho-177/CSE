#proj09#
#analyze data relevant to the biggest cybersecurity breaches in the past.#

#import
import csv
from operator import itemgetter
import matplotlib.pyplot as plt
import numpy as np

#open the file
def open_file(message):
    
    while 1:
        filename = input(message)
        if filename == '': filename = 'breachdata.csv'
        try:
            fp = open(filename, encoding='utf8')
            return fp
        except:
       
            print('[ - ] File not found. Try again.')
            filename = input(message)
            if filename == '': filename = 'breachdata.csv'
            fp = open(filename, encoding='utf8')
    
#extract the information from the data
def build_dict(reader):    
    next(reader,None)
    D = dict()
    
    for line in reader:
        
        D1,D2 = dict(),dict()
        
        entity = line [ 0 ] 
        if entity ==  '' : continue
    
        records_lost = line [ 2 ]
        if records_lost == '':
            records_lost = 0
        else:      
            records_lost = int ( line [2].replace(',','') )
        
        
        year = line [ 3 ] 
        if year == '':  continue
        try:
            year = int(year)
        except:
            continue
        
        story = line [ 4 ]
        if story == '':  continue
    
        sector = line [ 5 ]
        if sector == '': continue
    
        method = line [ 6 ]
        if method == '': continue
    
        news_sources = line [11]
        if news_sources == '':   continue
        else:     news_sources = news_sources.split(',')
        
       
        D1 [ entity ] = (records_lost, year, story, news_sources)
        D2 [year] = (sector,method)
        
        try:
            D [entity].append((D1,D2))
        except:
            D [entity] = [(D1,D2)]
            
    return D  

#get the top 10 records with entity    
def top_rec_lost_by_entity(D):
    
    L = []
    for key,value in D.items():
        records = 0
        for i in range(len(value)):
            records += value[i][0][key][0]
        L.append((key,records))
        
    return sorted(L,key = itemgetter(1),reverse = True)[:10]

#get the records with year
def records_lost_by_year(D):
    
    D1 = dict()
    for key,value in D.items():
        for i in range(len(value)):
            year = value[i][0][key][1]
            records = value[i][0][key][0]
            
            try:
                D1[year] += records
            except:
                D1[year] = records
    
    return sorted(D1.items(),key=itemgetter(1),reverse = True)

#get the information about methods and sector from the dict build above
def top_methods_by_sector(D):
    
    D1 = dict()
    for key,value in D.items():
        for i in range(len(value)):
            
            year = value[i][0][key][1]
            sector = value[i][1][year][0]
            methods = value[i][1][year][1]
            
            try:
                
                try:
                    D1[sector][methods] += 1
                except:
                    D1[sector][methods] = 1
                    
            except:
                
                D1[sector] = {}
                D1[sector][methods] = 1
                
    return D1

        
def top_rec_lost_plot(names,records):
    ''' Plots a bargraph pertaining to
        the cybersecurity breaches data '''
        
    y_pos = np.arange(len(names))

    plt.bar(y_pos, records, align='center', alpha=0.5,
            color='blue',edgecolor='black')
    plt.xticks(y_pos, names, rotation=90)
    plt.ylabel('#Records lost')
    plt.title('Cybersecurity Breaches',fontsize=20)
    plt.show()
    
def top_methods_by_sector_plot(methods_list):
    ''' Plots the top methods used to compromise
        the security of a sector '''
    methods = [] ; quantities = []
    for tup in methods_list:
        methods.append(tup[0])
        quantities.append(tup[1])
    labels = methods
    sizes = quantities
    colors = ['gold', 'yellowgreen', 'lightcoral', 'lightskyblue']

    plt.pie(sizes, labels=labels, colors = colors,
    autopct='%1.1f%%', shadow=True, startangle=140)
    
    plt.axis('equal')
    plt.show()
    
def main():
    BANNER = '''
    
                 _,.-------.,_
             ,;~'             '~;, 
           ,;                     ;,
          ;                         ;
         ,'                         ',
        ,;                           ;,
        ; ;      .           .      ; ;
        | ;   ______       ______   ; | 
        |  `/~"     ~" . "~     "~\'  |
        |  ~  ,-~~~^~, | ,~^~~~-,  ~  |
         |   |        }:{        |   | 
         |   l       / | \       !   |
         .~  (__,.--" .^. "--.,__)  ~. 
         |     ---;' / | \ `;---     |  
          \__.       \/^\/       .__/  
           V| \                 / |V  
            | |T~\___!___!___/~T| |  
            | |`IIII_I_I_I_IIII'| |  
            |  \,III I I I III,/  |  
             \   `~~~~~~~~~~'    /
               \   .       .   /
                 \.    ^    ./   
                   ^~~~^~~~^ 
                   
           
           ~~Cybersecurity Breaches~~        
                   @amirootyet    
                
    '''
    
    print(BANNER)
    
    MENU = '''  
[ 1 ] Most records lost by entities
[ 2 ] Records lost by year
[ 3 ] Top methods per sector
[ 4 ] Search stories
[ 5 ] Exit

[ ? ] Choice: '''
    
    judge = True #judge whether or not read a filename 
    ask = input(MENU)
    while 1:
        while ask.isdigit() == False or ask not in ['1','2','3','4','5']:
            print('[ - ] Incorrect input. Try again.')
            ask = input(MENU)
        
#read a filename in the loop first run        
        if judge == True and ask != '5':
            fp = open_file("[ ? ] Enter the file name: ")
            reader = csv.reader(fp)
            D = build_dict(reader)
            judge = False
            
#handle different situation 
            
        if ask == '1': 
            
            print("[ + ] Most records lost by entities...")
            
            L = top_rec_lost_by_entity(D)
            
            for i in range(len(L)):
                print("-"*45)
                print("[ {:2d} ] | {:15.10s} | {:10d}".format(i+1,L[i][0],L[i][1]))
                
            Plot = input('[ ? ] Plot (y/n)? ')
            
            if Plot.lower() == "y":
                
                names,records = [] , []
                
                for i in L:
                    
                    names.append(i[0])
                    records.append(i[1])
                    
                top_rec_lost_plot(names,records)

        elif ask == '2':
            
            print("[ + ] Most records lost in a year...")
            
            L = records_lost_by_year(D)
            
            for i in range(len(L)):
                print("-"*45)
                print("[ {:2d} ] | {:15.10s} | {:10d}".format(i+1,str(L[i][0]),L[i][1]))
                
            Plot = input("[ ? ] Plot (y/n)? ")
            
        elif ask == '3':
            
            print("[ + ] Loaded sector data.")
            
            L = top_methods_by_sector(D)
            
            print(" ".join(sorted(L.keys())))
            
            k = ''
            while k not in L.keys():
                k = input("[ ? ] Sector (case sensitive)? ")
                
            print("[ + ] Top methods in sector {}".format(k))
            
            Dis = []
            for key,value in L[k].items(): Dis.append((key,value))   
            Dis.sort(key=itemgetter(1),reverse = True)
            
            for i in range(len(Dis)):
                print("-"*45)
                print("[ {:2d} ] | {:15.10s} | {:10d}".format(i+1,Dis[i][0],Dis[i][1]))
                
            Plot = input("[ ? ] Plot (y/n)? ")
            if Plot.lower() == 'y': top_methods_by_sector_plot(Dis)
            
        elif ask == '4':
            
            while 1:
                
                A = input("[ ? ] Name of the entity (case sensitive)? ")
                
                if A not in D:
                    
                    print("[ - ] Entity not found. Try again.")
                    
                else:
                    
                    print("[ + ] Found {} stories:".format(len(D[A])))
                    for i in range(len(D[A])): print("[ + ] Story {}: {:10s}".format(i+1,D[A][i][0][A][2]))
                    break
#break when ask = 5               
        elif ask == '5':
            print('[ + ] Done. Exiting now...')    
            break
        
        ask = input(MENU)
  

if __name__ == "__main__":
     main()