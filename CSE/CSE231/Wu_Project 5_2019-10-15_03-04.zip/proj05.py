'''
project 05
this proj is to complete proj5
'''

#Retain these import statements  
import math

def open_file():
   #this function read a filename and return the File pointer
        filename = input ('Enter an <off> file name: ')
        try:   
           in_file = open(filename ,'r')
           return in_file
        except:
           print ('Error. Please try again')
           fp = open_file()
           
        return fp

def read_face_data (fp,index):
    #read face data
    fp.seek(0)
    line = fp.readline()
    line = fp.readline()
   
    skip = int ( line[0:5] )
    
    for i in range (skip+1+int(index)): line = fp.readline()
    
   

    return (int(line[3:8]),int(line[9:14]),int(line[15:20]))
        
def read_vertex_data (fp,index):
    #read vertex data
    fp.seek(0)
    line = fp.readline()
    line = fp.readline()
    

    for i in range (1+int(index)): line = fp.readline()
    
    
    
    return (float(line[0:15]),float(line[16:31]),float(line[32:47]))


        
def compute_cross(v1,v2,v3,w1,w2,w3):
    #computer cross
    a,b,c = 0.0, 0.0, 0.0
   
    a = v2*w3-v3*w2
    b = v3*w1-v1*w3
    c = v1*w2-v2*w1
        
    return ( round (a,5), round (b,5), round (c,5))
  
      
def compute_distance(x1,y1,z1,x2,y2,z2):
    #compute the distance between two points
    D = math.sqrt((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)
        
    return ( round (D,2) )


def compute_face_normal(fp,face_index):
    #compute a face's normal
    first, second, third = read_face_data(fp,face_index)
    
    x1,y1,z1 = read_vertex_data(fp,first)
    x2,y2,z2 = read_vertex_data(fp,second)
    x3,y3,z3 = read_vertex_data(fp,third)
    
    side1x, side1y, side1z = x1-x2, y1-y2, z1-z2
    side2x, side2y, side2z = x2-x3, y2-y3, z2-z3
    #side3x, side3y, side3z = x3-x1, y3-y1, z3-z1
    
    normal = compute_cross(side1x, side1y, side1z, side2x, side2y, side2z)
    
    return normal
    
    
def compute_face_area(fp,face_index):
     #compute a face's area
    first, second, third = read_face_data(fp,face_index)
    
    x1,y1,z1 = read_vertex_data(fp,first)
    x2,y2,z2 = read_vertex_data(fp,second)
    x3,y3,z3 = read_vertex_data(fp,third)
    
    A = compute_distance(x1,y1,z1,x2,y2,z2)
    B = compute_distance(x2,y2,z2,x3,y3,z3)
    C = compute_distance(x3,y3,z3,x1,y1,z1)
    
    p = ( A + B + C ) / 2
    Area = math.sqrt( p*(p-A)*(p-B)*(p-C) )
    
    return (round(Area,2))

def is_connected_faces(fp,f1_ind,f2_ind):
    #judge two faces whether or not share a side
    t = 0
    
    f1_point1, f1_point2, f1_point3 = read_face_data(fp,f1_ind)
    
    if f1_point1 in read_face_data(fp,f2_ind): t += 1
    if f1_point2 in read_face_data(fp,f2_ind): t += 1
    if f1_point3 in read_face_data(fp,f2_ind): t += 1
    
    if t == 2: return True 
    else: return False
    
def check_valid(fp,index,shape):
    # check if the value is valid
    fp.seek(0)
    
    if shape != 'face' and shape != 'vertex': return False
    
    line = fp.readline()
    line = fp.readline()
    
    try:
        vertexs = int ( line[0:5] )
        faces   = int ( line[6:10] )  
        if shape == 'vertex' and 0 <= int(index) < vertexs: return True
        if shape == 'face' and 0 <= int(index) < faces: return True
    except:
        return False
    
    return False

def table():
    #  print  choices table
     print('''\nPlease choose an option below:
        1- display the information of the first 5 faces
        2- compute face normal
        3- compute face area
        4- check two faces connectivity
        5- use another file
        6- exit\n       ''') 

def main():
    #main function 
    Test = '123456'
    
    print('''\nWelcome to Computer Graphics!
    We are creating and handling shapes. Any shape can be represented by polygon meshes, 
    which is a collection of vertices, edges and faces.''')
    
    ask = ''
    fp = open_file()
    while ask != '6':
        
        table()  #print choices table  when a loop begin
        ask = input ('>> Choice: ') #input choices
        
        
        while ask not in Test: 
            print('Please choose a valid option number.')
            ask = input ('>> Choice: ') #keep input until the choice is valid
         
            
   # different choices         
        if ask == '1':
            print ("{:^7s}{:^15s}".format('face', 'vertices'))
            
            for i in range(5):
                point1, point2, point3 = read_face_data (fp,i)
                print('{:5d}{:5d}{:5d}{:5d}'.format(i, point1, point2, point3))
                        
        elif ask == '2':
            
            index = input ('Enter face index as integer: ')
            while check_valid(fp,index,'face') == False:
               
                    print('This is not a valid face index.')
                    index = input ('Enter face index as integer: ')
                    
            a , b , c = compute_face_normal(fp,index)
            print('The normal of face %d:   '%int(index),a,b,c)
            
        
        elif ask == '3':
            
            index = input ('Enter face index as integer: ')
            
            while check_valid(fp,index,'face') == False:
                print('This is not a valid face index.')
                index = input ('Enter face index as integer: ')
                
            index = int (index)
            print('The area of face %d:    '%index,compute_face_area(fp,index)) 
            
        
        elif ask == '4':
            
            index1 = input('Enter face 1 index as integer: ')
            
           
            while check_valid(fp,index1,'face') == False:
                    print('This is not a valid face index.')
                    index1 = input('Enter face 1 index as integer: ')      
            
            
            index2 = input('Enter face 2 index as integer: ')
            
            while check_valid(fp,index2,'face') == False:
                    print('This is not a valid face index.')
                    index2 = input('Enter face 2 index as integer: ') 
                    
            if  is_connected_faces(fp,int(index1),int(index2)) == True: 
                print('The two faces are connected.')
            else:   
                print('The two faces are NOT connected.')
        elif ask == "5":
            fp = open_file()
                
        
            
            
            
        
    else:
        print('Thank you, Goodbye!') # print  after the loop naturally end (choice 6)
        
        
        
if __name__ == '__main__':
    main()

# finished here
    
    
    
    