print("\nWelcome to car rentals. ")
print()
print("At the prompts, please enter the following: " )
print("\tCustomer's classification code (a character: BDW) ")
print("\tNumber of days the vehicle was rented (int)")
print("\tOdometer reading at the start of the rental period (int)")
print("\tOdometer reading at the end of the rental period (int)")

n_str = input("\nWould you like to continue (Y/N)? ")
while n_str == 'Y' :
    code = input("\nCustomer code (BDW): ")
    while code != 'B' and code !='D' and code != 'W':
       print ("\n\t*** Invalid customer code. Try again. ***")
       code = input("\nCustomer code (BDW): ")
    day_str = input("\nNumber of days: ")
    day_f = float (day_str)
    start_str = input("Odometer reading at the start: ")
    end_str = input("Odometer reading at the end:   ") 
    start_f = int(start_str)
    end_f = int(end_str)
    driven = (float(end_f)-float(start_f))
    if driven<0: driven+=1000000
    driven = driven/10
    print("\nCustomer summary:")
    print("\tclassification code:",code)
    print("\trental period (days):",day_str)
    print("\todometer reading at start:",start_f)
    print("\todometer reading at end:  ",end_f)
    print("\tnumber of miles driven: ",driven)
    if code == 'D': 
        ava = driven/day_f
        if ava <100: due =60*day_f
        else: due = 60*day_f + (driven-100*day_f)*0.25
    elif code == 'B': due = day_f*40+driven*0.25
    elif code == 'W': 
        if (day_f%7) != 0 : week = day_f//7+1
        else: week = day_f //7
        ava = driven/week
        if ava<900: due = week*190
        elif 900 < ava < 1500: due=week*290      
        elif ava>1500: due = week*390+(driven-1500*week)*0.25
    print("\tamount due: $",due)
    n_str = input("\nWould you like to continue (Y/N)? ")
print("Thank you for your loyalty.")