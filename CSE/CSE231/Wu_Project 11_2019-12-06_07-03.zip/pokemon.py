"""
    SOURCE HEADER GOES HERE!
"""

from random import randint


#DO NOT CHANGE THIS!!!
# =============================================================================
is_effective_dictionary = {'bug': {'dark', 'grass', 'psychic'}, 
                           'dark': {'ghost', 'psychic'},
                           'dragon': {'dragon'}, 
                           'electric': {'water', 'flying'}, 
                           'fairy': {'dark', 'dragon', 'fighting'},
                           'fighting': {'dark', 'ice', 'normal', 'rock', 'steel'}, 
                           'fire': {'bug', 'grass', 'ice', 'steel'}, 
                           'flying': {'bug', 'fighting', 'grass'}, 
                           'ghost': {'ghost', 'psychic'}, 
                           'grass': {'water', 'ground', 'rock'}, 
                           'ground': {'electric', 'fire', 'poison', 'rock', 'steel'}, 
                           'ice': {'dragon', 'flying', 'grass', 'ground'}, 
                           'normal': set(), 
                           'poison': {'fairy', 'grass'}, 
                           'psychic': {'fighting', 'poison'}, 
                           'rock': {'bug', 'fire', 'flying', 'ice'},
                           'steel': {'fairy', 'ice', 'rock'},
                           'water': {'fire', 'ground', 'rock'}
                           }

not_effective_dictionary = {'bug': {'fairy', 'flying', 'fighting', 'fire', 'ghost','poison','steel'}, 
                            'dragon': {'steel'}, 
                            'dark': {'dark', 'fairy', 'fighting'},
                            'electric': {'dragon', 'electric', 'grass'},
                            'fairy': {'fire', 'poison', 'steel'},
                            'fighting': {'bug', 'fairy', 'flying', 'poison', 'psychic'}, 
                            'fire': {'dragon', 'fire', 'rock', 'water'}, 
                            'flying': {'electric', 'rock', 'steel'}, 
                            'ghost': {'dark'}, 
                            'grass': {'bug', 'dragon', 'grass', 'fire', 'flying', 'poison', 'steel'}, 
                            'ground': {'bug','grass'}, 
                            'ice': {'fire', 'ice', 'steel', 'water'}, 
                            'normal': {'rock', 'steel'}, 
                            'poison': {'ghost', 'ground', 'poison', 'rock'}, 
                            'psychic': {'psychic', 'steel'}, 
                            'rock': {'fighting', 'ground', 'steel'}, 
                            'steel': {'electric', 'fire', 'steel', 'water'},
                            'water': {'dragon','grass', 'ice'}
                            }

no_effect_dictionary = {'electric': {'ground'}, 
                        'dragon': {'fairy'},
                        'fighting': {'ghost'}, 
                        'ghost': {'normal', 'psychic'}, 
                        'ground': {'flying'}, 
                        'normal': {'ghost'}, 
                        'poison': {'steel'},
                        'psychic': {'dark'}, 
                        
                        'bug': set(), 'dark': set(), 'fairy': set(),'fire': set(), 
                        'flying': set(), 'grass': set(), 'ice': set(), 
                        'rock': set(), 'steel': set(), 'water': set()
                        }

#Dictionaries that determine element advantages and disadvantages
# =============================================================================

class Move(object):
    def __init__(self, name = "", element = "normal", power = 20, accuracy = 80,
                 attack_type = 2):
        """ Initialize attributes of the Move object """
        
        self.name = name
        self.element = element
        self.power = power
        
        self.accuracy = accuracy
        self.attack_type = attack_type  #attack_type is 1, 2 or 3 
        # 1 - status moves, 2 - physical attacks, 3 - special attacks
        
    def __str__(self):
            
        return self.name

    def __repr__(self):
        
        return self.name
    
    def get_name(self):
        
        return self.name
    
    def get_element(self):
        
        return self.element
    
    def get_power(self):
        
        return self.power
    
    def get_accuracy(self):
        
        return self.accuracy
    
    def get_attack_type(self):
        
        return self.attack_type

    def __eq__(self,m):
        '''return True if all attributes are equal; False otherwise'''
        return self.name == m.get_name() and self.element == m.get_element() and\
                self.power == m.get_power() and self.accuracy == m.get_accuracy() and\
                self.attack_type == m.get_attack_type()

    
class Pokemon(object):
    def __init__(self, name = "", element1 = "normal", element2 = "", moves = None,
                 hp = 100, patt = 10, pdef = 10, satt = 10, sdef = 10):
        ''' initializes attributes of the Pokemon object '''
        
        self.name = name
        self.element1 = element1
        self.element2 = element2
        
        self.hp = hp
        self.patt = patt
        self.pdef = pdef
        self.satt = satt
        self.sdef = sdef
        
        self.moves = moves
        
        try:
            if len(moves) > 4:
                self.moves = moves[:4]
                
        except TypeError: #For Nonetype
            self.moves = list()

    def __eq__(self,p):
        '''return True if all attributes are equal; False otherwise'''
        return self.name == p.name and \
            self.element1 == p.element1 and \
            self.element2 == p.element2 and \
            self.hp == p.hp and \
            self.patt == p.patt and \
            self.pdef == p.pdef and \
            self.satt == p.satt and \
            self.sdef == p.sdef and \
            self.moves == p.moves

    def __str__(self):
        line12 = '{:<15}{:<15}{:<15}{:<15}{:<15}{}\n{:<15}{:<}\n'.format(self.name,self.hp,self.patt,self.pdef,self.satt,self.sdef,self.element1,self.element2)
        line3 = ''
        for i in range(len(self.moves)):
            line3 += '{:<15}'.format(self.moves[i].get_name())

        return line12+line3

    def __repr__(self):
        
        line12 = '{:<15}{:<15}{:<15}{:<15}{:<15}{}\n{:<15}{:<}\n'.format(self.name,self.hp,self.patt,self.pdef,self.satt,self.sdef,self.element1,self.element2)
        line3 = ''
        for i in range(len(self.moves)):
            line3 += '{:<15}'.format(self.moves[i].get_name())

        return line12+line3


    def get_name(self):
        
        return self.name
    
    def get_element1(self):
        
        return self.element1
    
    def get_element2(self):
        
        return self.element2
    
    def get_hp(self):
        
        return self.hp
    
    def get_patt(self):
        
        return self.patt

    def get_pdef(self):
        
        return self.pdef

    def get_satt(self):
        
        return self.satt

    def get_sdef(self):
        
        return self.sdef
    
    def get_moves(self):
        
        return self.moves

    def get_number_moves(self):
        
        return len(self.moves)

    def choose(self,index):
        
        try:
            return self.moves[index]
        except IndexError:
            return None

        
    def show_move_elements(self):
        
       
        for move in self.moves:
            element = move.get_element()
            print('{:<15}'.format(element),end = '')
        
    


    def show_move_power(self):
        
        for move in self.moves:
            power = move.get_power()
            print('{:<15}'.format(power),end = '')
        

    def show_move_accuracy(self):
        
        for move in self.moves:
            Ac = move.get_accuracy()
            print('{:<15}'.format(Ac),end = '')
        
        
    def add_move(self, move):
        
        if self.get_number_moves() <= 3:
            self.moves.append(move)
        
    def attack(self, move, opponent):
        power = move.get_power()
        att_type = move.get_attack_type()
        if att_type == 1: 
            return None
        elif att_type == 2: 
            Att = self.get_patt()
            Def = opponent.get_pdef()
           
        elif att_type == 3: 
            Att = self.get_satt()
            Def = opponent.get_sdef()
        else:
            print("Invalid attack_type, turn skipped.")
            return None
           
        Ac = randint(1,100)
        if Ac > move.get_accuracy():
            print("Move missed!")
            return None
        
        modifier = 1.0
#        print(opponent.get_element1(),opponent.get_element2(),move.get_element())
        if opponent.get_element1() in is_effective_dictionary[move.get_element()]:  modifier *= 2
        if opponent.get_element2() in is_effective_dictionary[move.get_element()]:  modifier *= 2
        if opponent.get_element1() in not_effective_dictionary[move.get_element()]: modifier *= 0.5
        if opponent.get_element2() in not_effective_dictionary[move.get_element()]: modifier *= 0.5
        if opponent.get_element1() in no_effect_dictionary[move.get_element()] or opponent.get_element2() in no_effect_dictionary[move.get_element()]:  modifier = 0
        if move.get_element()==self.element1 or move.get_element()==self.element2: modifier *= 1.5
        if modifier == 0:
            print("No effect!")
            return None
        if modifier < 1:
            print("Not very effective...")
        if modifier >= 2:
            print("It's super effective!!!!")
        damage = ((power*(Att/Def)*20)/50+2)*modifier
        
        damage = int(damage)
       # damage = (power*(Att/Def)*20/50 + 2) * modifier
        opponent.subtract_hp(damage)
        
        
        
    def subtract_hp(self,damage):
        self.hp = self.hp-damage if self.hp>damage else 0
        return self.hp

        