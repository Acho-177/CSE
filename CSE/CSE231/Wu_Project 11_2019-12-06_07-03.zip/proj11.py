"""
proj11
Pokémon is a very successful franchise not only in Japan and the United States, but worldwide.

"""
import csv
from random import randint
from random import seed
from copy import deepcopy

from pokemon import Pokemon
from pokemon import Move

seed(1) #Set the seed so that the same events always happen

"""
    SOURCE HEADER GOES HERE!
"""
        
#DO NOT CHANGE THIS!!!
# =============================================================================
element_id_list = [None, "normal", "fighting", "flying", "poison", "ground", "rock", 
                   "bug", "ghost", "steel", "fire", "water", "grass", "electric", 
                   "psychic", "ice", "dragon", "dark", "fairy"]

#Element list to work specifically with the moves.csv file.
#   The element column from the moves.csv files gives the elements as integers.
#   This list returns the actual element when given an index
# =============================================================================
    
def read_file_moves(fp):  
    reader = csv.reader(fp)
    next (reader,None)
    moves = []
    for line in reader:
       
        if line [6] == '' or line [4] == '' or line[2] !='1' or line [9] == '1': continue
        move = Move(line[1] , element_id_list[int(line[3])] , int (line [4]) , int (line [6]) , int (line [9]))
        moves.append(move)
#    for line in fp:
#        name = line [1]
#        element = element_id_list[line[2]]
#        damage_class = line [9]
#        power = int ( line [4] )
#        pp = line [5]
#        ac = int ( line [6] )
#        priority = line [7]
#        target_id = line [8]
#        if ac == '' or power == '' or line[3] !=1 or damage_class == 1: continue
#        move = [name,element,power,ac,damage_class]
#        moves.append(move)
    return moves


def read_file_pokemon(fp):
    reader = csv.reader(fp)
    next (reader,None)
    pokemons = []
    L = []
    for line in reader:
        if line[11] != '1': continue
        if line[0] not in L:
            L.append(line[0])
            pokemon = Pokemon (line[1].lower(),line[2].lower(),line[3].lower(),None,int(line[5]),int(line[6]),int(line[7]),int(line[8]),int(line[9]))
            pokemons.append(pokemon)
        
    return pokemons    

def choose_pokemon(choice,pokemon_list):
    try:
        choice = int(choice)
        try:
            return deepcopy(pokemon_list[choice-1])
        except:
            return None
    except:
        for index,pokemon in enumerate(pokemon_list):
            if pokemon.get_name() == choice.lower():
                return deepcopy(pokemon_list[index])
        return None
            

def add_moves(pokemon,moves_list):
    
    for i in range(200):
        
        index = randint(0,len(moves_list)-1)
        if pokemon.get_number_moves() == 0:
            pokemon.add_move(moves_list[index])
        element1 = pokemon.get_element1()
        element2 = pokemon.get_element2()
        elements = [element1,element2]
      #  print(moves_list[index].get_name())
#        print(moves_list[index].get_element().lower())
        if moves_list[index].get_element() in elements:
            if moves_list[index] not in pokemon.get_moves(): 
                pokemon.add_move(moves_list[index])
        if pokemon.get_number_moves() == 4: return True
    return False
            
def turn (player_num, player_pokemon, opponent_pokemon):
    
    options = "Show options: 'show ele', 'show pow', 'show acc'\n" + "Select an attack between 1 and {} or show option or 'q': ".format(player_pokemon.get_number_moves())
    Test = ['show ele', 'show pow', 'show acc']
    
    print("Player {}'s turn".format(player_num))
    print(player_pokemon)
    
    ask = input(options).lower()
    
    while ask in Test:
        if ask == 'show ele':  player_pokemon.show_move_elements()
        if ask == 'show pow':  player_pokemon.show_move_power()
        if ask == 'show acc':  player_pokemon.show_move_accuracy()
        ask = input(options).lower()
        
    if ask == 'q':
        print("Player {} quits, Player {} has won the pokemon battle!".format(1,2)) if int(player_num) == 1 else print("Player {} quits, Player {} has won the pokemon battle!".format(2,1))
        return False
    
    name = opponent_pokemon.get_name()
    move = int(ask)-1
    
    print('selected move:',player_pokemon.choose(move))
    
    print("{} hp before:{}".format(name,opponent_pokemon.get_hp()))
    player_pokemon.attack(player_pokemon.choose(move),opponent_pokemon)
    print("{} hp after:{}".format(name,opponent_pokemon.get_hp()))
    
    
    if opponent_pokemon.get_hp() > 0:
        if int(player_num) == 2:
            print("Player 1 hp after:",opponent_pokemon.get_hp())
            print("Player 2 hp after:",player_pokemon.get_hp())
            
    else:
        print("Player {}'s pokemon fainted, Player {} has won the pokemon battle!".format(2,1)) if player_num == 1 else  print("Player {}'s pokemon fainted, Player {} has won the pokemon battle!".format(1,2))
        return False
    
    return True

def main():
    Test = ['n','q','y']
    
    fp1 = open('moves.csv',encoding = 'utf-8')
    m_list = read_file_moves(fp1)
    fp1.close()
    
    fp2 = open('pokemon.csv',encoding = 'utf-8')
    p_list = read_file_pokemon(fp2)
    fp2.close()
    
    
    Game = input("Would you like to have a pokemon battle? ").lower()
    while 1:
        while Game not in Test:
            Game = input("Invalid option! Please enter a valid choice: Y/y, N/n or Q/q: ").lower()
            
        if Game == 'y':
            
            player1 = input("Player {}, choose a pokemon by name or index: ".format(1))
            while 1:
                pokemon_player1 = choose_pokemon(player1.lower(),p_list)
                if pokemon_player1 is not None:
                    
                    print('pokemon1:')
                    print(' ',pokemon_player1)
                    
                    add_moves(pokemon_player1,m_list)
                    break
                
                else: 
                    player1 = input("Invalid option, choose a pokemon by name or index: ")
                    
            player2 = input("Player {}, choose a pokemon by name or index: ".format(2))
            while 1:
                pokemon_player2 = choose_pokemon(player2.lower(),p_list)
                if pokemon_player2 is not None:
                    
                    print('pokemon2:')
                    print(' ',pokemon_player2)
                    
                    add_moves(pokemon_player2,m_list)
                    break
                
                else: 
                    player2 = input("Invalid option, choose a pokemon by name or index: ")
            player_num = 1
            
            while True:
                
                if player_num == 1:
                    player_num = 2
                    if turn(1,pokemon_player1,pokemon_player2) == False:
                        Game = input("Battle over, would you like to have another? ").lower()
                        break
                else:
                    player_num = 1
                   
                    if turn(2,pokemon_player2,pokemon_player1) == False:
                        Game = input("Battle over, would you like to have another? ").lower()
                        break
        else:
            print("Well that's a shame, goodbye")
            return
                    
if __name__ == "__main__":
    main()