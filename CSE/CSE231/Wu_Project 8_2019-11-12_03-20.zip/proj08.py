# proj 08#
#t a simpler way to understand how an application may go about finding the words itself#

# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 17:59:14 2019

@author: WHY
"""
from itertools import combinations
from itertools import permutations
from operator import itemgetter
SCORE_DICT = {'a':1, 'e':1, 'i':1, 'o':1, 'u':1, 'l':1, 'n':1, 's':1, 't':1, 'r':1,
              'd':2, 'g':2,
              'b':3, 'c':3, 'm':3, 'p':3,
              'f':4, 'h':4, 'v':4, 'w':4,'y':4,
              'k':5,
              'j':8, 'x':8 }

def open_file():
    name = input('Input word file: ')
    try:
            
        fp = open(name,encoding="ISO-8859-1")
        return fp
    
    except:
        
        print ('Error: file not found.')
        fp = open_file()
            
    return fp

def read_file(fp):
    Dict = dict()
    
    for word in fp:
        
        word = word[:-1]
        
        if word.isalpha():
            
            if len(word) > 2:
                
                Dict[word.lower()] = 1
            
    return Dict

def calculate_score(rack,word):
    
    score = 0
    
    lens = len(rack)
    
    
    for i in word:
        
        score += SCORE_DICT [i]
        
        if i in rack:
            
            rack = rack.replace(i,'',1)
            
            
    if rack == '' and lens <= len(word) and lens>6: score += 50
    
    return score

def generate_combinations(rack, placed_tile):
    L = ()
    Set = set()
    
    if placed_tile == '':
        
        for i in rack: L += (i,)
        
        Set.add(L)
        
        return Set
    
    for i in range(2,len(rack)+1):
        for j in combinations(rack,i):
            
            Tuple = j + (placed_tile,)
            Set.add(Tuple)
            
    return Set
    
def generate_words(combo,scrabble_words_dict):
   
    Set = set() 
    
    for j in permutations(combo):
        word = ''.join(j)
        
        if word in scrabble_words_dict.keys():
            Set.add(word)
            
    return Set

def generate_words_with_scores(rack,placed_tile,scrabble_words_dict):
    
    Set_of_set = set()
    Dict = dict()
    Set =set()
    
    if placed_tile == '':
        
        for i in range(2,len(rack)+1):
            for j in combinations(rack,i):
                
                Tuple = j + (placed_tile,)
                Set.add(Tuple)
        
    else: Set = generate_combinations(rack, placed_tile)
    
    
    for i in Set:
        Set_of_set.add(tuple(generate_words(i,scrabble_words_dict)))
   
    
    for i in Set_of_set:
        for j in i:
            Dict [j] = calculate_score(rack,j)
            
    return Dict

def sort_words(word_dic):
    L = []
    T = ()
    
    for key,value in word_dic.items():
        T = (key,value,len(key))
        L.append(T)
        
    L.sort()
    
    L.sort(key = itemgetter(1,2),reverse = True)
    L_score = L[:]
    
    L.sort(key = itemgetter(2,1),reverse = True)
    L_len = L[:]
    
    return L_score,L_len

def display_words(L,strs):
    
    Range = 5
    
    if len(L) < 5: Range = len(L)
    
    if strs == 'score': k = 1
    
    else: k =2
    
    for i in range(0,Range):
        print("{:>6d}  -  {:s}".format(L[i][k],L[i][0]))
    
    
    
def main():
    
  print('Scrabble Tool')
  
  ask = input('Would you like to enter an example (y/n): ').lower()
  
  while ask == 'y':
      
      fp = open_file()
      Dict = read_file(fp)
      fp.close()
      
      new_dict = dict()
      word_dict = dict()
      
      rack = input ('Input the rack (2-7chars): ')
      tiles = input ('Input tiles on board (enter for none): ')
      
      if tiles == '':
          
          word_dict = generate_words_with_scores(rack,tiles,Dict)
          
      else:
          
          for i in tiles:
              
              new_dict = generate_words_with_scores(rack,i,Dict)
              word_dict.update(new_dict)
              
      L_score,L_len = sort_words(word_dict)
      
      
      print('Word choices sorted by Score')
      print("{:>6s}  -  {:s}".format('Score','Word'))
      display_words(L_score,'score')
      
      
      print('Word choices sorted by Length')
      print("{:>6s}  -  {:s}".format('Length','Word'))  
      display_words(L_len,'lens')
      
      
      ask = input('Do you want to enter another example (y/n): ')
      
      
  print('Thank you for playing the game')
  
if __name__ == '__main__':
    main()