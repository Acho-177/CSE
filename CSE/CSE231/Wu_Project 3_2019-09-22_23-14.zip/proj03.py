Level_test = 'freshman, sophomore, junior, senior'
College_test = 'business, engineering, health, sciences'

Ask = 'yes'
James = ''
College = ''

def judge(t):
    
     if t != 'yes': t = 'no'
     return t

def judge_2(t):
    
    if t not in College_test: t = 'none'
    return t


print('2019 MSU Undergraduate Tuition Calculator.\n')

while Ask == 'yes':

    Fee = 0
    
    Resident = judge (input ('Resident (yes/no): ').lower() )
    
    if Resident == 'no' :
        International = input ('International (yes/no): ')
        
        
    Level = input('Level—freshman, sophomore, junior, senior: ').lower()

    while Level not in Level_test: 
    
        print('Invalid input. Try again.')
   
        Level = input('Level—freshman, sophomore, junior, senior: ').lower()
    
    if Level == 'junior' or Level == 'senior':
       
        College = judge_2 ( input ('Enter college as business, engineering, health, sciences, or none: ').lower() )
        
        major = judge ( input ('Is your major CMSE (“Computational Mathematics and Engineering”) (yes/no): ').lower() )
        
        if  College not in College_test :
            James = judge ( input('Are you in the James Madison College (yes/no): ').lower() )      
        
    else:
        Coe = judge ( input('Are you admitted to the College of Engineering (yes/no): ').lower() )
        
        if Coe == 'no': James = judge ( input('Are you in the James Madison College (yes/no): ').lower() )        
      
            
     
    
    while 1:
        Credits =  input ('Credits: ') 
        if Credits.isdigit() == False or Credits == '0':
            print('Invalid input. Try again.')
        else: break
       
    Credits = float (Credits)
        
             
     
    
    if College == 'engineering': 
            if Credits < 5: Fee += 402
            else: Fee += 670
    
    
    if Resident == 'yes':
        
        if Level == 'freshman': 
            if Credits < 12:    Fee += 482 * Credits
            elif Credits < 19:  Fee += 7230
            else: Fee += 7230 + (Credits-18)*482
            
        elif Level == 'sophomore': 
            if Credits < 12:    Fee += 494 * Credits
            elif Credits < 19:  Fee += 7410
            else: Fee += 7410 + (Credits-18)*494
        
        else: 
            if College == 'engineering' or College == 'business' :
                
                if Credits < 12:    Fee += 573 * Credits
                elif Credits < 19:  Fee += 8595
                else: Fee += 8595 + (Credits-18)*573
                
                if College == 'business':
                    if Credits < 5: Fee += 113
                    else: Fee += 226
                    
            else:
                if Credits < 12:    Fee += 555 * Credits
                elif Credits < 19:  Fee += 8325
                else: Fee += 8325 + (Credits-18)*555
    else:
        
        if Level == 'freshman' or Level == 'sophomore': 
            if Credits < 12:    Fee += 1325.5 * Credits
            elif Credits < 19:  Fee += 19883
            else: Fee += 19883 + (Credits-18)*1325.5
            
        
        else: 
            if College == 'engineering' or College == 'business' :
                if Credits < 12:    Fee += 1385.75 * Credits
                elif Credits < 19:  Fee += 20786
                else: Fee += 20786 + (Credits-18)*1385.75
            else:
                if Credits < 12:    Fee += 1366.75 * Credits
                elif Credits < 19:  Fee += 20501
                else: Fee += 20501 + (Credits-18)*1366.75
    
    
    if Level == 'junior' or Level == 'senior':
        
        
        if College == 'health': 
            if Credits < 5: Fee += 50
            else: Fee += 100
            
        if College == 'sciences': 
            if Credits <5: Fee += 50
            else: Fee += 100
            
        if major == 'yes':
            if Credits < 5: Fee += 402
            else: Fee += 670
            
        
    if Resident == 'no': 
        
        if Credits <5: Fee += 375
        else: Fee += 750
     
    Fee += 24
    
    if Credits > 5: Fee += 5
    if James == 'yes': Fee += 7.5
       
    Fee = str (Fee)
    
    left = Fee
    right = ''
    
    for i,ch in enumerate(Fee):
        if ch == '.':
            left = Fee [0:i]
            right = Fee [i+1:]
            
    result = '' 
    
    while len(left) != 0:
        result = left[-3:] +',' +result
        left = left [:-3]
    
    if right == '' or right == '0' : right = '00'
    
    value = result[:-1] + '.' + right + '.'   
    
    print('Tuition is $%s'%value)
    
    Ask = judge ( input('Do you want to do another calculation (yes/no): ').lower() )

