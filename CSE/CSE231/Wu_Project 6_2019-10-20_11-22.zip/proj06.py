'''Header comment goes here'''
import csv
from operator import itemgetter

PROMPT = '''
Choose
         (1) Top sites by country
         (2) Search by web site name
         (3) Top sites by views
         (q) Quit
         
Choice: '''

         
def open_file():
    name = input('Input a filename: ')
    try:
            
        fp = open(name,encoding="ISO-8859-1")
        return fp
    
    except:
        print ('Error: file not found.')
        fp = open_file()
            
    return fp        
    
        


def read_file(fp):
    
    reader = csv.reader(fp)
    
    next (reader,None)
    
    data_list = []
    
    for line in reader: 
        
        infor_list = []
        
        try:
            infor_list.append(int(line[0]))
        except:
            continue
        infor_list.append(line[1])
        try:
            infor_list.append(int(line[14].replace(' ',''))) 
        except:
            continue
        try:
            infor_list.append(int(line[5].replace(' ','')))
        except:
            continue
        infor_list.append(line[30])
        
        data_list.append(tuple(infor_list))
        
    data_list.sort(key = itemgetter(0,4) )
    
    return data_list
            
            
            
def remove_duplicate_sites(L_of_L):
    
    WEB = ''
    new_list = []
    
    for infor in L_of_L:
            
        webname = infor[1][infor[1].find('.')+1:infor[1].find('.',infor[1].find('.')+1)]    
          
        if webname not in WEB:  
            WEB += webname
            new_list.append(infor)
            
    new_list.sort( key = itemgetter(0,1) )
    return new_list
            
    


def top_sites_per_country(L_of_L,country):
    
    new_lists = []
    
    for infor in L_of_L:
        
        if infor[4] == country:        
           
            new_lists.append(infor)
            
    new_lists.sort( key = itemgetter(0))
    
    return new_lists[0:20]

def top_sites_per_views(L_of_L):
    
    L_of_L.sort (key = itemgetter(3), reverse = True)
    
    L_of_L = remove_duplicate_sites(L_of_L)
    
    L_of_L.sort (key = itemgetter(3), reverse = True)
    
    return L_of_L[0:20]
    
def main():
    
    print('----- Web Data -----')
    fp = open_file()
    Ls = read_file(fp)
    
    ask = ''
   
    
    while ask.lower() != 'q':
        
        print(PROMPT)
        
           
        ask = input()
    
        if ask in '123qQ': pass
        else:
           print('Incorrect input. Try again.')
               
        if ask == '1': 
            
           print('--------- Top 20 by Country -----------')

           country = input('Country: ')
           
           L = top_sites_per_country(Ls,country)
           
           print('{:30s} {:>15s}{:>30s}'.format('Website','Traffic Rank','Average Daily Page Views'))
           
           for infor in L:
               
               print('{:30s} {:>15d}{:>30,d}'.format(infor[1],infor[2],infor[3]))
        
        if ask == '2':
            
            t = 0
            
            s = input('Search: ')
            
            print("{:^50s}".format("Websites Matching Query"))
            
            for infor in Ls:
                if s.lower() in infor[1]: 
                    print(infor[1])
                    t += 1     
            if t == 0 : print('None found')     
            
        if ask == '3':
            
            print ('--------- Top 20 by Page View -----------')
            
            L = top_sites_per_views(Ls)
            
            print (('{:30s} {:>20s}'.format('Website','Ave Daily Page Views')))
            
            for infor in L:
                
                print('{:30s} {:>20,d}'.format(infor[1],infor[3]))
            
           
            
   
   
   
if __name__ == "__main__":
     main()