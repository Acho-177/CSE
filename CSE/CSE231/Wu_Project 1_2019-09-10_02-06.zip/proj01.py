# first program in python
# input two numbers, add them together, print them out
# wfp, 9/1/07; rje, 5/5/14

str1=input('Input rods: ')
float1=float(str1)
print('You input',float1,'rods.')
print()
print('Conversions')
Meters=float1*5.0292
Feet=float1*16.5
Miles=Meters/1609.34
Furlongs=float1/40
Minutes=(Miles/3.1)*60
print('Meters:',round(Meters,3))
print('Feet:',round(Feet,3))
print('Miles:',round(Miles,3))
print('Furlongs:',round(Furlongs,3))
print('Minutes to walk',float1,'rods:',round(Minutes,3))