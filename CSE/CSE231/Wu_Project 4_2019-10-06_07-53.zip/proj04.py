#proj04

import math


#Initialization
Begin = '''\nPlease choose one of the options below:
             A. Display the value of the sum of the first N natural numbers. 
             B. Display the approximate value of e.
             C. Display the approximate value of the hyperbolic sine of X.
             D. Display the approximate value of the hyperbolic cosine of X.
             M. Display the menu of options.
             X. Exit from the program.'''
EP = 1e-7
Test = 'ABCDMX'
Input = 'M'


def is_float(n):
    try:
        n = float(n)
        return True
    except:
        return False

def factorial(n):
     
    t = 1
    
    while n != 1:
        t = t*n
        n -= 1
    
    return t
    


def sum_natural(N):
    
    if N == '0': return None
    if N.isdigit() == False: return None
    
    else:
        
        N = int (N)
        
        return int((N*(N+1))/2)
    
def approximate_euler():
    
    e , k , term = 0.0 , 0 , 1

    while term > EP:
        e += term 
        k += 1
        term = 1/factorial(k) 
     
    return round(e,10)


def approximate_sinh(x):
    
  
    
    try:
        sinh , k , term = 0.0 , -1 , 1
        x = float(x)
        while abs(term) > EP:
            
            k += 1
            sinh += term 
            term = (x**(2*k+1))/factorial(2*k+1)
            
        return round(sinh-1.0,10)
    
    except:
        return None

def approximate_cosh(x):
    
 
    
    try:
        cosh , k , term = 0.0 , 0 , 1
        x = float(x)
        while abs(term) > EP:
            
            k += 1
            cosh += term 
            term = (x**(2*k))/factorial(2*k)
            
        return round(cosh,10)
    
    except:
        return None
    
def main():
   
    Begin = '''\nPlease choose one of the options below:
             A. Display the value of the sum of the first N natural numbers. 
             B. Display the approximate value of e.
             C. Display the approximate value of the hyperbolic sine of X.
             D. Display the approximate value of the hyperbolic cosine of X.
             M. Display the menu of options.
             X. Exit from the program.'''
    
    Test = 'ABCDMX'
    Input = 'M'


    while Input != 'X':
      
    
        if Input == 'M': 
        
            print(Begin)
        
        Input = input ('	Enter option: ').upper()
    
        while Input not in Test:
        
            print ('\nError:  unrecognized option [%s]'%Input)
            print (Begin)
            Input = input ('	Enter option: ').upper()
    
      
    
        if Input == 'X': print ('Hope to see you again.')
    
        if Input == 'A':
        
          
            n = input ('\nEnter N: ')
        
    
            if sum_natural(n) == None:
                
                if is_float(n) == True:
                
                    print('\n        Error: N was not a valid natural number. [%s]\n'%n)
                continue
                    
                                         
            print('\n        The sum:  %d\n'%sum_natural(n))
            
            
    
        if Input == 'B':
        
        
        
            print('\n        Approximation: %.10f'%approximate_euler())
            print('        Math module:   %.10f'%math.e)
            
            diff = abs ( round(approximate_euler(),10) - round( math.e ,10) )
        
            print ('        difference:    %.10f\n'%diff)
        
        
        if Input == 'C':
        
   
          
            n = input ('\nEnter X: ')
        
    
            if is_float (n) == False:  print('\n        Error: X was not a valid float. [%s]\n'%n)
          
            
            else:  
                
                sinh = round(approximate_sinh(n),10)
                
                print('\n        Approximation: %.10f'%sinh)
                print('        Math module:   %.10f'%math.sinh(float(n)))
        
                diff = abs (sinh - round(math.sinh(float(n)),10))
        
                print ('        difference:    %.10f\n'%diff)
                
    
            
        if Input == 'D':
        

          
            n = input ('\nEnter X: ')
        
    
            if is_float (n) == False:  print('\n        Error: X was not a valid float. [%s]\n'%n)
          
            
            else:  
                
                cosh = round(approximate_cosh(n),10)
                
                print('\n        Approximation: %.10f'%cosh)
                print('        Math module:   %.10f'%math.cosh(float(n)))
        
                diff = abs (cosh - round(math.cosh(float(n)),10))
        
                print ('        difference:    %.10f\n'%diff)


if __name__ == "__main__":  
    main()    
    
    
    
    
    