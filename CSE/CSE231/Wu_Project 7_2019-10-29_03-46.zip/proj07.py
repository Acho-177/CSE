"""
    OF COURSE THIS PROGROM IS FOR PROJ07
"""

import matplotlib.pyplot as plt
import csv
from operator import itemgetter

MIN_YEAR = 2009
MAX_YEAR = 2017


def open_file(prompt_str):
    
    filename = input ('Enter %s file: '%prompt_str,)
    
    try:
        fp = open(filename,'r',encoding="utf-8 ") 
    
    except:
        print ('File not found! Try Again!\n')
        fp = open_file(prompt_str)
            
    return fp     
    


def read_travel_file(fp):
    
    reader = csv.reader(fp)
    
    next (reader,None)
    
    data_lists = []
    travel_file_lists = []
    
    for line in reader:
           
        infor_list = []
           
        Departures = float ( line[3] )
        Arrivals = float ( line[4] )
        Expenditures = float ( line[5] )
        Receipts = float ( line[6] )
        
        if Departures == 0 : 
            avg_expenditures = 0
        else:
            avg_expenditures = Expenditures/Departures
            
        if Arrivals == 0 :
            avg_receipts = 0
        else:
            avg_receipts = Receipts/Arrivals
           
        infor_list.append(int(line[0]))
        infor_list.append(line[1][:20])
        infor_list.append(line[2])
        infor_list.append(Arrivals/1000)
        infor_list.append(Departures/1000)
        infor_list.append(Expenditures/1000000)
        infor_list.append(Receipts/1000000)
        infor_list.append(round( avg_expenditures , 2))
        infor_list.append(round( avg_receipts , 2))
           
        data_lists.append(tuple( infor_list ))
        
    year_lists = []     
    
    n = 2009
    
    for i in range(len(data_lists)) :
        
        n = n - data_lists [i][0]
        
        if n != 0:
            travel_file_lists.append((year_lists))
            year_lists = []
            
      
        year_lists.append(tuple(data_lists [i]))
        year_lists.sort( key = itemgetter (1))    
       
        n = data_lists [i][0]
        
        if n == 2017:
            for j in range (i+1,len(data_lists)):
                year_lists.append(tuple(data_lists [j]))
            year_lists.sort( key = itemgetter (1))  
            travel_file_lists.append((year_lists))
            break
            
    return travel_file_lists



def read_country_code_file(fp):
    
    lines = fp.readlines()
    
    country_code_list = []
    
    for i in range(1,len(lines)):
        
        infor_list = []
        
        for j,ch in enumerate(lines[i]):
            if ch == '/': 
                infor_list.append(lines[i][:j].replace('\n',''))
                infor_list.append(lines[i][j+1:].replace('\n',''))
        
                country_code_list.append( tuple ( infor_list ) )
        
        
    return sorted(country_code_list)

def get_country_code_data(country_code, L):
    
    infor_list = []
    
    for lists in L:
        
        for infor in lists:
            
            if infor [2] == country_code:
                
                infor_list.append(infor)
                
    return infor_list


def display_country_data(country_list):
    '''
        WRITE DOCSTRING HERE!!!
    '''
    
    # Get the country name from the list
    country_name = country_list[0][1]
    
    # Print table title
    title = "Travel Data for {}".format(country_name)
    print("{:^80s}".format(title))
    
    # Table headers
    header = ['Year', 'Departures','Arrivals','Expenditures', 'Receipts']
    units = ['','(thousands)','(thousands)','(millions)','(millions)']
    
    # header string formatting
    # '{:6s}{:>15s}{:>15s}{:>15s}{:>15s}'
    
    # Numeric values string formatting
    # '{:<6d}{:>15,.2f}{:>15,.2f}{:>15,.2f}{:>15,.2f}'
    
    print('{:6s}{:>15s}{:>15s}{:>15s}{:>15s}'.format('Year', 'Departures','Arrivals','Expenditures', 'Receipts'))
    print('{:6s}{:>15s}{:>15s}{:>15s}{:>15s}'.format('','(thousands)','(thousands)','(millions)','(millions)'))
    total1,total2,total3,total4 = 0,0,0,0
    for i in range(len(country_list)):
        
        total1 += country_list[i][4]
        total2 += country_list[i][3]
        total3 += country_list[i][5]
        total4 += country_list[i][6]
        
        print ('{:<6d}{:>15,.2f}{:>15,.2f}{:>15,.2f}{:>15,.2f}'.format(country_list[i][0],country_list[i][4],country_list[i][3],country_list[i][5],country_list[i][6],))
    print()
    print('{:<6s}{:>15,.2f}{:>15,.2f}{:>15,.2f}{:>15,.2f}'.format('Total',total1,total2,total3,total4))
    print()
def display_year_data(year_list):
    '''
        WRITE DOCSTRING HERE!!!
    '''
    
    # Get the year from the list
    year = year_list[0][0]
    
    # Print table title
    title = "Travel Data for {:d}".format(year)
    print("\n{:^80s}".format(title))
    
    # Table headers
    header = ['Country Name', 'Departures','Arrivals','Expenditures',\
              'Receipts']
    units = ['','(thousands)','(thousands)','(millions)','(millions)']
    
    # header string formatting
    # '{:25s}{:15s}{:15s}{:15s}{:15s}'
    
    # Rows string formatting
    # '{:20s}{:>15,.2f}{:>15,.2f}{:>15,.2f}{:>15,.2f}'
    print('{:25s}{:15s}{:15s}{:15s}{:15s}'.format('Country Name', 'Departures','Arrivals','Expenditures','Receipts'))
    print('{:25s}{:15s}{:15s}{:15s}{:15s}'.format('','(thousands)','(thousands)','(millions)','(millions)'))
    total1,total2,total3,total4 = 0,0,0,0
    for i in range(len(year_list)):
        
    
            total1 += year_list[i][4]
            total2 += year_list[i][3]
            total3 += year_list[i][5]
            total4 += year_list[i][6]
            
            print('{:<20s}{:>15,.2f}{:>15,.2f}{:>15,.2f}{:>15,.2f}'.format(year_list[i][1],year_list[i][4],year_list[i][3],year_list[i][5],year_list[i][6]),)
    print()
    print('{:20s}{:>15,.2f}{:>15,.2f}{:>15,.2f}{:>15,.2f}'.format('Total',total1,total2,total3,total4))
    print()
def prepare_bar_plot(year_list):
    
   
    infor_list1 = []
    infor_list2 = []
    
    for List in year_list:
        
        infor = []
        
        infor.append(List[1])
        infor.append(List[7])
        
        infor_list1.append(tuple(infor))
    
    for List in year_list:
        
        infor = []
        
        infor.append(List[1])
        infor.append(List[8])
        
        infor_list2.append(tuple(infor))
        
    infor_list1.sort(key = itemgetter(1), reverse =True)   
    infor_list2.sort(key = itemgetter(1), reverse =True)   
    
    return infor_list1[:20],infor_list2[:20]
    

def prepare_line_plot(country_list):
    
    infor_list1,infor_list2 = [], []
    for List in country_list:
        
        infor_list1.append(List[7])
        infor_list2.append(List[8])
    
    return infor_list1[:20],infor_list2[:20]


def plot_bar_data(expend_list, receipt_list, year):
    '''
        This function plots the the top 20 countries with the highest average
        expenditures and the top 20 countries with the highest receipts.
        
        Returns: None
    
    '''

    # prepare the columns
    countries_expend = [elem[0] for elem in expend_list]
    values_expend = [elem[1] for elem in expend_list]
    
    countries_receipt = [elem[0] for elem in receipt_list]
    values_receipt = [elem[1] for elem in receipt_list]
    
    # Average expenditures
    
    x = range(20) # top 20 countries are to be plotted.

    fig, axs = plt.subplots(2, 1,figsize=(7,10))
    title = "Top 20 countries with highest average expenditures {:4d}".format(year)
    axs[0].set_title(title)
    axs[0].bar(x, values_expend, width=0.4, color='b')
    axs[0].set_ylabel("Avg. Expenditures (US dollar)")
    axs[0].set_xticks(x)
    axs[0].set_xticklabels(countries_expend , rotation='90')
    
    # Average receipt
    title = "Top 20 countries with highest average receipt  {:4d}".format(year)
    axs[1].set_title(title)
    axs[1].set_ylabel("Avg. Receipts (US dollar)")
    axs[1].bar(x, values_receipt, width=0.4, color='b')
    axs[1].set_xticks(x)
    axs[1].set_xticklabels(countries_receipt , rotation='90')
    fig.tight_layout()
    #plt.show()
    
    ##comment the previous line and uncomment the following two lines when trying to pass Test 4
    fig.savefig('avg_expense_receipts.png',dpi=100)
    fig.clf()


def plot_line_data(country_code, expend_list, receipt_list):
    '''
        Plot the line plot for the expenditures and receipts for the
        country between 2009 and 2017
        
        Returns: None
    '''
    
    
    title = "Average expenditures and receipts for {} between 2009 and 2017".format(country_code)
    years = range(MIN_YEAR, MAX_YEAR+1)
    fig, axs = plt.subplots(figsize=(7,5))
    axs.set_title(title)
    axs.set_ylabel("Cost (US dollar)")
    axs.plot(years, expend_list, years, receipt_list)
    axs.legend(['Expenditures','Receipt'])

    #plt.show()
    
    ##comment the previous line and uncomment the following two lines when trying to pass Test 4
    fig.savefig('line.png',dpi=100)
    fig.clf()

def main():
    '''
        WRITE DOCSTRING HERE!!!
    '''
    
    BANNER = "International Travel Data Viewer\
    \n\nThis program reads and displays departures, arrivals, expenditures,"\
    " and receipts for international travels made between 2009 and 2017.\n"
    
    # Prompt for option
    OPTION = "Menu\
    \n\t1: Display data by year\
    \n\t2: Display data by country\
    \n\t3: Display country codes\
    \n\t4: Stop the Program\
    \n\n\tEnter option number: "
    
    
    print(BANNER)
    
    fp1 = open_file('the travel data')
    print()
    fp2 = open_file('the country code')
    travel_data_file = read_travel_file(fp1)
    country_code = read_country_code_file(fp2)
    
    
    while True:
        
        ask = input (OPTION)
        
        if ask == '1':
            
            year = input ('Enter year: ')
            while int(year) not in range(2009,2018):
                print('Year needs to be between 2009 and 2017. Try Again!')
                year = input ('Enter year: ')
            display_year_data(travel_data_file[int(year)-2009])
            
            
            re = input ('Do you want to plot (yes/no)? ')
            
            expend_list, receipt_list = prepare_bar_plot(travel_data_file[int(year)-2009])
            
            if re.lower() == 'yes': 
           
                plot_bar_data(expend_list, receipt_list,int(year))  
                
        if ask == '2':
            
            while True:
                code = input ('Enter country code: ')
            
                country_list = []
            
                for i in range(len(travel_data_file)):
                    for j in range(len(travel_data_file[i])):
                        if travel_data_file[i][j][2] == code.upper():
                            country_list.append(travel_data_file[i][j])
                            
                if country_list == []:
                    print('Country code is not found! Try Again!')
                    continue
                
                print()
                display_country_data(country_list)
                
            
                re = input ('Do you want to plot (yes/no)? ')
                expend_list, receipt_list = prepare_line_plot(country_list)
                if re.lower() == 'yes': 
                    plot_line_data(code.upper(),expend_list, receipt_list)
                
                break
            
        if ask == '3':
            
            print('\nCountry Code Reference')
            print('{:15s}{:25s}'.format('Country Code','Country Name'))
            for List in country_code:
                print('{:15s}{:25s}'.format(List[0],List[1]))

            
        if ask == '4':
            break
        
        if ask not in '1234':
            print('Invalid option. Try Again!')
    
    print("\nThanks for using this program!")
        
if __name__ == "__main__":
    main()