#pragma once
#include <string>
#include <vector>

#include "Drawable.h"
/**
 * A drawable based on polygon images.
 *
 * This class has a list of points and draws a polygon
 * drawable based on those points.
 */

class CPolyDrawable: public CDrawable
{
public:

	CPolyDrawable(const std::wstring& name);

    /** \brief Default constructor disabled */
    CPolyDrawable() = delete;
    /** \brief Copy constructor disabled */
    CPolyDrawable(const CPolyDrawable&) = delete;
    /** \brief Assignment operator disabled */
    void operator=(const CPolyDrawable&) = delete;

    /** The polygon color
    * \returns mColor */
    Gdiplus::Color GetColor() const { return mColor; }
    /** Set polygon color
    * \param color New color */
    void SetColor(Gdiplus::Color color) { mColor = color; }

    virtual void Draw(Gdiplus::Graphics* graphics) override;
    virtual bool HitTest(Gdiplus::Point pos) override;
    /**IsMovable
    * \return bool   */
    virtual bool IsMovable() { return false; }

    void AddPoint(Gdiplus::Point point);

private:
	/// The polygon color
	Gdiplus::Color mColor = Gdiplus::Color::Black;
	/// The array of point objects
	std::vector<Gdiplus::Point> mPoints;
};

