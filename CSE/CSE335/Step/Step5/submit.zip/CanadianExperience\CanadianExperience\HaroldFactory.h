#pragma once
#include <memory>
#include "Actor.h"
/**
 * Factory class that builds the Harold character
 */
class CHaroldFactory
{
public:
	std::shared_ptr<CActor> Create();
};
