#include "pch.h"
#include "CppUnitTest.h"
#include "Actor.h"
using namespace Gdiplus;
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Testing
{
	TEST_CLASS(CActorTest)
	{
	public:

		TEST_METHOD_INITIALIZE(methodName)
		{
			extern wchar_t g_dir[];
			::SetCurrentDirectory(g_dir);
		}
		
		TEST_METHOD(TestNothing)
		{
			// This is an empty test just to ensure the system is working
		}

		TEST_METHOD(CActorConstructorTest)
		{
			CActor actor(L"Name");
			Assert::AreEqual(std::wstring(L"Name"), actor.GetName());
		}

		TEST_METHOD(CActorEnabledTest)
		{
			CActor actor(L"Name");
			Assert::IsTrue(actor.IsEnabled());
			actor.SetEnabled(false);
			Assert::IsFalse(actor.IsEnabled());
		}

		TEST_METHOD(CActorClickabledTest)
		{
			CActor actor(L"Name");
			Assert::IsTrue(actor.IsClickable());
			actor.SetClickable(false);
			Assert::IsFalse(actor.IsClickable());
		}

		TEST_METHOD(CActorPositiondTest)
		{
			CActor actor(L"Name");
			Assert::AreEqual(0, actor.GetPosition().X);
			Assert::AreEqual(0, actor.GetPosition().Y);

			actor.SetPosition(Gdiplus::Point(10, 20));
			Assert::AreEqual(10, actor.GetPosition().X);
			Assert::AreEqual(20, actor.GetPosition().Y);
		}
	};
}