/**
 * \file ViewEdit.h
 *
 * \author Haoyun Wu
 *
 * View class the provides a window for editing our pixture
 */

#pragma once
#include "PictureObserver.h"
class CMainFrame;
class CActor;  // Forward reference
class CDrawable;  // Forward reference

/** View class the provides a window for editing our pixture */
class CViewEdit : public CScrollView, public CPictureObserver
{
	DECLARE_DYNCREATE(CViewEdit)

public:
	CViewEdit();           // protected constructor used by dynamic creation
	virtual ~CViewEdit();

	/**
	 * Set the mainFrame pointer
	 * \param mainFrame Pointer to the CMainFrame window
	 */
	void SetMainFrame(CMainFrame* mainFrame) { mMainFrame = mainFrame; }

	virtual void UpdateObserver() override;

protected:
	/** overridden to draw this view
	*\param pDC */
	virtual void OnDraw(CDC* pDC);      
	virtual void OnInitialUpdate();     // first time after construct

	DECLARE_MESSAGE_MAP()

public:
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);

    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);

private:
	/// The main frame window that uses this view
	CMainFrame* mMainFrame = nullptr;

	std::shared_ptr<CActor> mSelectedActor;		///<mSelectedActor
	std::shared_ptr<CDrawable> mSelectedDrawable;	///<mSelectedDrawable

	/// The last mouse position
	Gdiplus::Point mLastMouse = Gdiplus::Point(0, 0);
};


