#pragma once
#include <string>
#include <memory>
#include "Drawable.h"

/**
 * CImageDrawable
 *
 */
class CImageDrawable : public CDrawable
{
public:
	CImageDrawable(const std::wstring& name, const std::wstring& filename);
	void Draw(Gdiplus::Graphics* graphics);
	bool HitTest(Gdiplus::Point pos);

	/**Get mCenter
	*\return mCenter*/
	Gdiplus::Point GetCenter() const { return mCenter; }
	/**Set mCenter
	*\param point New Center*/
	void SetCenter(Gdiplus::Point point) { mCenter = point; }

	/**IsMovable
	* \return bool   */
	virtual bool IsMovable() { return false; }
protected:
	/// The image for this drawable
	std::unique_ptr<Gdiplus::Bitmap> mImage;
private:
	Gdiplus::Point mCenter = Gdiplus::Point(0, 0);///< mCenter
};

