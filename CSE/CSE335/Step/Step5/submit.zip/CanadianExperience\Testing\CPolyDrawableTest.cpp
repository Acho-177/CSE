#include "pch.h"
#include "CppUnitTest.h"
#include "PolyDrawable.h"
#include "gdipluscolor.h"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace Gdiplus;

bool CheckColor(Color color1, Color color2)
{
	return color1.GetValue() == color2.GetValue();
}

namespace Testing
{
	TEST_CLASS(CPolyDrawableTest)
	{
	public:

		TEST_METHOD_INITIALIZE(methodName)
		{
			extern wchar_t g_dir[];
			::SetCurrentDirectory(g_dir);
		}
		
		TEST_METHOD(TestNothing)
		{
			// This is an empty test just to ensure the system is working
		}

		TEST_METHOD(CPolyDrawableConstructorTest)
		{
			CPolyDrawable polyDrawable(L"Name");
			Assert::AreEqual(std::wstring(L"Name"), polyDrawable.GetName());
		}

		TEST_METHOD(CPolyDrawableColorTest)
		{
			CPolyDrawable polyDrawable(L"Name");

			Assert::IsTrue(CheckColor(Color::Black, polyDrawable.GetColor()));

			polyDrawable.SetColor(Color::Red);

			Assert::IsTrue(CheckColor(Color::Red, polyDrawable.GetColor()));
		}
	};
}