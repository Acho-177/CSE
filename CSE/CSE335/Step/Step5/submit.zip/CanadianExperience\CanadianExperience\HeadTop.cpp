#include "pch.h"
#include "HeadTop.h"
#include <string>
using namespace Gdiplus;
/// Constant ratio to convert radians to degrees
const double RtoD = 57.295779513;

/** Constructor
 * \param name The drawable name
 * \param filename The filename for the image */
CHeadTop::CHeadTop(const std::wstring& name, const std::wstring& filename) :
    CImageDrawable(name, filename)
{
}

bool CHeadTop::IsMovable()
{
    return true;
}

void CHeadTop::Draw(Gdiplus::Graphics* graphics)
{
    CImageDrawable::Draw(graphics);

    Point p1 = TransformPoint(Point(30, 50));
    Point p2 = TransformPoint(Point(60, 50));
    DrowEyeBrow(p1, graphics);
    DrowEyeBrow(p2, graphics);

    float wid = 15.0f;
    float hit = 20.0f;
    SolidBrush brush(Color::Black);

    auto state = graphics->Save();
    Point p5 = TransformPoint(Point(40, 70));
    graphics->TranslateTransform(p5.X, p5.Y);
    graphics->RotateTransform((float)(-mPlacedR * RtoD));
    graphics->FillEllipse(&brush, -wid / 2, -hit / 2, wid, hit);
    graphics->Restore(state);

    state = graphics->Save();
    Point p6 = TransformPoint(Point(70, 70));
    graphics->TranslateTransform(p6.X, p6.Y);
    graphics->RotateTransform((float)(-mPlacedR * RtoD));
    graphics->FillEllipse(&brush, -wid / 2, -hit / 2, wid, hit);
    graphics->Restore(state);
}

/** Transform a point from a location on the bitmap to
*  a location on the screen.
* \param  p Point to transform
* \returns Transformed point
*/
Gdiplus::Point CHeadTop::TransformPoint(Gdiplus::Point p)
{
    // Make p relative to the image center
    p = p - GetCenter();

    // Rotate as needed and offset
    return RotatePoint(p, mPlacedR) + mPlacedPosition;
}

/// <summary>
/// DrowEyeBrow
/// </summary>
/// <param name="point"></param>
/// <param name="graphics"></param>
void CHeadTop::DrowEyeBrow(Gdiplus::Point point, Gdiplus::Graphics* graphics)
{
    auto point2 = Point( point.X + 20, point.Y);
    Pen eyebrowPen(Color::Black, 2);
    graphics->DrawLine(&eyebrowPen, point, point2);
}
