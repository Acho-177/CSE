#pragma once
#include "ImageDrawable.h"
/**
 * The HeadTop we are drawing.
 *
 */
class CHeadTop : public CImageDrawable
{
public:
	
	CHeadTop(const std::wstring& name, const std::wstring& filename);

	/**IsMovable
	* \return bool   */
	virtual bool IsMovable() override;

	/**Draw
	* \param graphics   */
	virtual void Draw(Gdiplus::Graphics* graphics);
	Gdiplus::Point TransformPoint(Gdiplus::Point p);

	void DrowEyeBrow(Gdiplus::Point point, Gdiplus::Graphics* graphics);
};

