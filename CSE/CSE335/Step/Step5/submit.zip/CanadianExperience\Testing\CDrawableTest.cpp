#include "pch.h"
#include "CppUnitTest.h"
#include "Drawable.h"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Testing
{
	class CDrawableMock : public CDrawable
	{
	public:
		CDrawableMock(const std::wstring& name) : CDrawable(name) {}

		virtual void Draw(Gdiplus::Graphics* graphics) override {}
		virtual bool HitTest(Gdiplus::Point pos) override { return false; }

	};

	TEST_CLASS(CDrawableTest)
	{
	public:

		TEST_METHOD_INITIALIZE(methodName)
		{
			extern wchar_t g_dir[];
			::SetCurrentDirectory(g_dir);
		}
		
		TEST_METHOD(TestNothing)
		{
			// This is an empty test just to ensure the system is working
		}

		TEST_METHOD(CDrawableConstructorTest)
		{
			CDrawableMock drawable(L"Name");
			Assert::AreEqual(std::wstring(L"Name"), drawable.GetName());
		}

		TEST_METHOD(CDrawablePositionTest)
		{
			CDrawableMock drawable(L"Name");
			
			Assert::AreEqual(0, drawable.GetPosition().X);
			Assert::AreEqual(0, drawable.GetPosition().Y);

			drawable.SetPosition(Gdiplus::Point(10, 20));

			Assert::AreEqual(10, drawable.GetPosition().X);
			Assert::AreEqual(20, drawable.GetPosition().Y);
		}

		TEST_METHOD(CDrawableRotationTest)
		{
			CDrawableMock drawable(L"Name");

			Assert::AreEqual(0, drawable.GetRotation(), 0.00001);
			drawable.SetRotation(0.12);
			Assert::AreEqual(0.12, drawable.GetRotation(), 0.00001);
		}

		TEST_METHOD(TestCDrawableAssociation)
		{
			CDrawableMock body(L"Body");
			auto arm = std::make_shared<CDrawableMock>(L"Arm");
			auto leg = std::make_shared<CDrawableMock>(L"Leg");

			Assert::IsNull(arm->GetParent());
			Assert::IsNull(leg->GetParent());

			body.AddChild(arm);
			body.AddChild(leg);

			Assert::IsTrue(arm->GetParent() == &body);
			Assert::IsTrue(leg->GetParent() == &body);
		}
	};
}