#pragma once
#include <memory>
#include "Actor.h"
/**
 * Factory class that builds the my character
 */
class CMyCharactorFactory
{
public:
	std::shared_ptr<CActor> Create();
};
