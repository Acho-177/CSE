#include "pch.h"
#include "CppUnitTest.h"
#include "PictureObserver.h"
#include "Picture.h"

using namespace std;
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Testing
{
	class CPictureObserverMock : public CPictureObserver
	{
	public:
		CPictureObserverMock() : CPictureObserver() {}
		virtual void UpdateObserver() override { mUpdated = true; }
		bool mUpdated = false;
	};

	TEST_CLASS(CPictureObserverTest)
	{
	public:

		TEST_METHOD_INITIALIZE(methodName)
		{
			extern wchar_t g_dir[];
			::SetCurrentDirectory(g_dir);
		}
		
		TEST_METHOD(TestNothing)
		{
			// This is an empty test just to ensure the system is working
		}

		TEST_METHOD(TestCPictureObserverConstruct)
		{
			CPictureObserverMock observer;
		}

		TEST_METHOD(TestCPictureObserverOneObserver)
		{
			// Allocate a CPicture object
			shared_ptr<CPicture> picture = make_shared<CPicture>();

			// Create a mock observer object
			CPictureObserverMock observer;

			// And set it for the observer:
			observer.SetPicture(picture);

			picture->UpdateObservers();

			Assert::IsTrue(observer.mUpdated);
		}

		TEST_METHOD(TestCPictureObserverGetter)
		{
			// Allocate a CPicture object
			shared_ptr<CPicture> picture1 = make_shared<CPicture>();

			// Create a mock observer object
			CPictureObserverMock observer1;

			Assert::IsTrue(observer1.GetPicture() == nullptr);

			// And set it for the observer:
			observer1.SetPicture(picture1);

			Assert::IsFalse(observer1.GetPicture() == nullptr);
		}

		TEST_METHOD(TestCPictureObserverTwoObserver)
		{
			// Allocate a CPicture object
			shared_ptr<CPicture> picture1 = make_shared<CPicture>();

			// Create a mock observer object
			CPictureObserverMock observer1;

			// And set it for the observer:
			observer1.SetPicture(picture1);

			picture1->UpdateObservers();

			Assert::IsTrue(observer1.mUpdated);

			// Allocate a CPicture object
			shared_ptr<CPicture> picture2 = make_shared<CPicture>();

			// Create a mock observer object
			CPictureObserverMock observer2;

			// And set it for the observer:
			observer2.SetPicture(picture2);

			picture2->UpdateObservers();

			Assert::IsTrue(observer2.mUpdated);
		}

		TEST_METHOD(TestCPictureObserverDestroy)
		{
			// Allocate a CPicture object
			shared_ptr<CPicture> picture = make_shared<CPicture>();

			// Create a mock observer object
			CPictureObserverMock observer;

			// And set it for the observer:
			observer.SetPicture(picture);

			picture->UpdateObservers();

			Assert::IsTrue(observer.mUpdated);

			{
				CPictureObserverMock observer2;

				// And set it for the observer:
				observer2.SetPicture(picture);

				picture->UpdateObservers();

				Assert::IsTrue(observer.mUpdated);
			}

			Assert::IsTrue(observer.mUpdated);
		}
	};
}