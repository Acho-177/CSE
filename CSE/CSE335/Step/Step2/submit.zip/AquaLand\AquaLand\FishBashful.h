/**
 * \file FishBashful.h
 *
 * \author Charles B. Owen
 *
 * Class the implements a Bashful fish
 */

#pragma once

#include <memory>
#include "Item.h"


 /**
  * Implements a Bashfulfish
  */
class CFishBashful : public CItem
{
public:

    CFishBashful(CAquarium* aquarium);

    /// Default constructor (disabled)
    CFishBashful() = delete;

    /// Copy constructor (disabled)
    CFishBashful(const CFishBashful&) = delete;


    virtual void Draw(Gdiplus::Graphics* graphics) override;

    virtual void DrawintoRed(Gdiplus::Graphics* graphics) override;

    bool HitTest(int x, int y);
private:
    ///check the fish's color
    bool isRed = true;
    /// fish image
    std::unique_ptr<Gdiplus::Bitmap> mFishImagegreen;
    /// fish image
    std::unique_ptr<Gdiplus::Bitmap> mFishImagered;
};