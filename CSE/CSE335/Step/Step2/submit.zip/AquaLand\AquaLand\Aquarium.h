/**
 * \file Aquarium.h
 *
 * \author Charles B. Owen
 *
 * Class that represents an aquarium.
 */
#pragma once

#include <memory>
#include <vector>

class CItem;

/**
 * Represents an aquarium
 */
class CAquarium
{
public:
    CAquarium();

    void OnDraw(Gdiplus::Graphics* graphics);

    void Add(std::shared_ptr<CItem> item);

    /**add bashfulful if it is
    * \param item
    * */
    void addBashfulFish(std::shared_ptr<CItem> item)
    {
        mBashfulFish.push_back(item);
    }

    void pushBack(std::shared_ptr<CItem> item);

    double Distance(std::shared_ptr<CItem> item1, std::shared_ptr<CItem> item2);
    //int size() { return mItems.size(); }

    std::shared_ptr<CItem> HitTest(int x, int y);
private:
    std::unique_ptr<Gdiplus::Bitmap> mBackground; ///< Background image to use

    /// All of the items to populate our aquarium
    std::vector<std::shared_ptr<CItem> > mItems;

    /// All of the bashfulfish to populate our aquarium
    std::vector<std::shared_ptr<CItem> > mBashfulFish;
};
