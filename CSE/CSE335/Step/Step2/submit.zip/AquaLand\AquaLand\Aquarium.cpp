/**
 * \file Aquarium.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include "Item.h"
#include "Aquarium.h"
#include "FishBeta.h"
#include "FishDory.h"
#include "FishBashful.h"
#include "FishAngelfish.h"
#include <string>
#include <memory>
using namespace std;
using namespace Gdiplus;

/**
 * Constructor
 */
CAquarium::CAquarium()
{
    mBackground = unique_ptr<Bitmap>(Bitmap::FromFile(L"images/background1.png"));
    if (mBackground->GetLastStatus() != Ok)
    {
        AfxMessageBox(L"Failed to open images/background1.png");
    }

    
}


/** Draw the aquarium
* \param graphics The GDI+ graphics context to draw on
*/
void CAquarium::OnDraw(Gdiplus::Graphics* graphics)
{
    graphics->DrawImage(mBackground.get(), 0, 0,
        mBackground->GetWidth(), mBackground->GetHeight());

    FontFamily fontFamily(L"Arial");
    Gdiplus::Font font(&fontFamily, 16);

    SolidBrush green(Color(0, 64, 0));
    graphics->DrawString(L"Under the Sea!", -1, &font, PointF(2, 2), &green);

    for (auto item : mItems)
    {
        bool drawed = false;
        bool isBashfish = false;
        for (auto mFish : mBashfulFish)
            if (item == mFish) isBashfish = true;
        if (isBashfish)
        { 
            for (auto item2 : mItems)
            {
                if (Distance(item, item2) > 0 && Distance(item, item2) < 200)
                {
                    item->DrawintoRed(graphics);
                    drawed = true;
                }
                if (drawed) break;
            }
            if (!drawed) item->Draw(graphics);
        }
        else item->Draw(graphics);
    }
}

/**
 * Add an item to the aquarium
 * \param item New item to add
 */
void CAquarium::Add(std::shared_ptr<CItem> item)
{
    mItems.push_back(item);
}

/** Test an x,y click location to see if it clicked
* on some item in the aquarium.
* \param x X location
* \param y Y location
* \returns Pointer to item we clicked on or nullptr if none.
*/
std::shared_ptr<CItem> CAquarium::HitTest(int x, int y)
{
    for (auto i = mItems.rbegin(); i != mItems.rend(); i++)
    {
        if ((*i)->HitTest(x, y))
        {
            return *i;
        }
    }

    return  nullptr;
}

/**
 * push the current fish to the front
 * \param item item need to push
 */
void CAquarium::pushBack(std::shared_ptr<CItem> item)
{
    auto loc = find(begin(mItems), end(mItems), item);
    if (loc != end(mItems))
    {
        std::shared_ptr<CItem> replaceitem = *loc;
        mItems.erase(loc);
        mItems.push_back(replaceitem);
    }
}

/**
 * check the distance between fish
 * \param item1
 * \param item2
 * \return a double of distance
 */
double CAquarium::Distance(std::shared_ptr<CItem> item1, std::shared_ptr<CItem> item2)
{

    // Distance in the X and Y directions
    double dx = item1->GetX() - item2->GetX();
    double dy = item1->GetY() - item2->GetY();

    double distance = sqrt(dx * dx + dy * dy);
    return distance;
}
