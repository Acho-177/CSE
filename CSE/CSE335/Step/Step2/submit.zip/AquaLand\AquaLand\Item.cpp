/**
 * \file Item.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include "Item.h"
#include "Aquarium.h"
#include <memory>
#include <string>
using namespace std;
using namespace Gdiplus;
/// Fish filename 
const wstring FishBasefulImageNameRed = L"images/bashful-red.png";

 /** Constructor
 * \param aquarium The aquarium this item is a member of
 */
CItem::CItem(CAquarium* aquarium) : mAquarium(aquarium)
{
}


/**
 * Destructor
 */
CItem::~CItem()
{
}

