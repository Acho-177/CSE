/**
 * \file FishBashful.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include "Aquarium.h"
#include <string>
#include "FishBashful.h"
using namespace std;
using namespace Gdiplus;

/// Fish filename 
const wstring FishBasefulImageNameGreen = L"images/bashful-green.png";
/// Fish filename 
const wstring FishBasefulImageNameRed = L"images/bashful-red.png";

/** Constructor
 * \param aquarium The aquarium this is a member of
*/
CFishBashful::CFishBashful(CAquarium* aquarium) : CItem(aquarium)
{
    mFishImagegreen = unique_ptr<Bitmap>(Bitmap::FromFile(FishBasefulImageNameGreen.c_str()));
    mFishImagered = unique_ptr<Bitmap>(Bitmap::FromFile(FishBasefulImageNameRed.c_str()));
    //mFishImagered = unique_ptr<Bitmap>(Bitmap::FromFile(FishBasefulImageNameRed.c_str()));
    if (mFishImagegreen->GetLastStatus() != Ok)
    {
        wstring msg(L"Failed to open ");
        msg += FishBasefulImageNameGreen;
        AfxMessageBox(msg.c_str());
    }
    if (mFishImagered->GetLastStatus() != Ok)
    {
        wstring msg(L"Failed to open ");
        msg += FishBasefulImageNameRed;
        AfxMessageBox(msg.c_str());
    }
}



/**
 * Draw our fish
 * \param graphics The graphics context to draw on
 */
void CFishBashful::Draw(Gdiplus::Graphics* graphics)
{
    double wid = mFishImagegreen->GetWidth();
    double hit = mFishImagegreen->GetHeight();
    graphics->DrawImage(mFishImagegreen.get(),
        float(GetX() - wid / 2), float(GetY() - hit / 2),
        (float)mFishImagegreen->GetWidth(), (float)mFishImagegreen->GetHeight());
}

/**
 * Test to see if we hit this object with a mouse.
 * \param x X position to test
 * \param y Y position to test
 * \return true if hit.
 */
bool CFishBashful::HitTest(int x, int y)
{
    if (isRed)
    {
        double wid = mFishImagered->GetWidth();
        double hit = mFishImagered->GetHeight();

        // Make x and y relative to the top-left corner of the bitmap image
        // Subtracting the center makes x, y relative to the image center
        // Adding half the size makes x, y relative to theimage top corner
        double testX = x - GetX() + wid / 2;
        double testY = y - GetY() + hit / 2;

        // Test to see if x, y are in the image
        if (testX < 0 || testY < 0 || testX >= wid || testY >= hit)
        {
            // We are outside the image
            return false;
        }

        // Test to see if x, y are in the drawn part of the image
        auto format = mFishImagered->GetPixelFormat();
        if (format == PixelFormat32bppARGB || format == PixelFormat32bppPARGB)
        {
            // This image has an alpha map, which implements the 
            // transparency. If so, we should check to see if we
            // clicked on a pixel where alpha is not zero, meaning
            // the pixel shows on the screen.
            Color color;
            mFishImagered->GetPixel((int)testX, (int)testY, &color);
            return color.GetAlpha() != 0;
        }
        else {
            return true;
        }

    }
    else
    {double wid = mFishImagegreen->GetWidth();
    double hit = mFishImagegreen->GetHeight();

    // Make x and y relative to the top-left corner of the bitmap image
    // Subtracting the center makes x, y relative to the image center
    // Adding half the size makes x, y relative to theimage top corner
    double testX = x - GetX() + wid / 2;
    double testY = y - GetY() + hit / 2;

    // Test to see if x, y are in the image
    if (testX < 0 || testY < 0 || testX >= wid || testY >= hit)
    {
        // We are outside the image
        return false;
    }

    // Test to see if x, y are in the drawn part of the image
    auto format = mFishImagegreen->GetPixelFormat();
    if (format == PixelFormat32bppARGB || format == PixelFormat32bppPARGB)
    {
        // This image has an alpha map, which implements the 
        // transparency. If so, we should check to see if we
        // clicked on a pixel where alpha is not zero, meaning
        // the pixel shows on the screen.
        Color color;
        mFishImagegreen->GetPixel((int)testX, (int)testY, &color);
        return color.GetAlpha() != 0;
    }
    else {
        return true;
    }
    }
}

/**
 * Draw our fish into red
 * \param graphics The graphics context to draw on
 */
void CFishBashful::DrawintoRed(Gdiplus::Graphics* graphics)
{
    isRed = true;
    double wid = mFishImagered->GetWidth();
    double hit = mFishImagered->GetHeight();
    graphics->DrawImage(mFishImagered.get(),
        float(GetX() - wid / 2), float(GetY() - hit / 2),
        (float)mFishImagered->GetWidth(), (float)mFishImagered->GetHeight());
}