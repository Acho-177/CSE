/**
 * \file FishAngelfish.h
 *
 * \author Charles B. Owen
 *
 * Class the implements a Beta fish
 */

#pragma once

#include <memory>

#include "Item.h"


 /**
  * Implements a Angelfish
  */
class CFishAngelfish : public CItem
{
public:
    CFishAngelfish(CAquarium* aquarium);

    /// Default constructor (disabled)
    CFishAngelfish() = delete;

    /// Copy constructor (disabled)
    CFishAngelfish(const CFishAngelfish&) = delete;


    virtual void Draw(Gdiplus::Graphics* graphics) override;

    bool HitTest(int x, int y);

private:
    /// fish image
    std::unique_ptr<Gdiplus::Bitmap> mFishImage;
};