/**
 * \file FishDory.h
 *
 * \author Charles B. Owen
 *
 * Class the implements a Dory fish
 */

#pragma once

#include <memory>

#include "Item.h"


 /**
  * Implements a Doryfish
  */
class CFishDory : public CItem
{
public:
    CFishDory(CAquarium* aquarium);

    /// Default constructor (disabled)
    CFishDory() = delete;

    /// Copy constructor (disabled)
    CFishDory(const CFishDory&) = delete;


    virtual void Draw(Gdiplus::Graphics* graphics) override;

    bool HitTest(int x, int y);

private:
    /// fish image
    std::unique_ptr<Gdiplus::Bitmap> mFishImage;
};