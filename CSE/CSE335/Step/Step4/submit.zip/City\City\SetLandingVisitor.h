#pragma once
#include "TileVisitor.h"
#include "TileRocketPad.h"
#include "Rocket.h"
/** get pad without rocket which can be used for landing
**/
class CSetLandingVisitor :
    public CTileVisitor
{
public:
    /** get rocket
* \returns mRocket */
    std::shared_ptr<CRocket> getRocket() { return mRocket; }
    /** get pad
* \returns mPad */
    CTileRocketPad* getPad() { return mPad; }

    /** visit part
* \param pad */
    void VisitRocketPad(CTileRocketPad* pad)
    {
        if (pad->getRocket() == nullptr)
            mPad = pad;
    }
private:

    ///mRocket
    std::shared_ptr<CRocket> mRocket = nullptr;

    ///mPad
    CTileRocketPad* mPad = nullptr;
};

