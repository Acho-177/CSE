#include "pch.h"
#include "IsPadVisitor.h"
