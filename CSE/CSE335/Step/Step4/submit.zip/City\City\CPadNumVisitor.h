#pragma once
#include "TileVisitor.h"
/**
 *  count pads
 */
class CPadNumVisitor :
    public CTileVisitor
{
public:
    /** Get the number of pads
 * \returns Number of pads */
    int GetNumPads() const { return mPadnums; }

    /** Visit a CTileBuilding object
* \param pad Pad we are visiting */
    void VisitRocketPad(CTileRocketPad* pad)
    {
        mPadnums++;
    }
private:
    /// Pads counter
    int mPadnums = 0;
};