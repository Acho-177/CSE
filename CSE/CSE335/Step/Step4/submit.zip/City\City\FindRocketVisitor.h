#pragma once
#include "TileVisitor.h"
#include "TileRocketPad.h"
/**
 *  find the pad which has rocket
 */
class CFindRocketVisitor :
    public CTileVisitor
{
public:
    /**
 *  get the rocket
 * \return mRocket
 */
    std::shared_ptr<CRocket> getRocket() { return mRocket; }
    
    /**
 *  get the pad
 * \return mPad
 */
    CTileRocketPad* getPad() { return mPad; }

    /**
 *  visit the clss
 * \param pad
 */
    void VisitRocketPad(CTileRocketPad* pad)
    {
        if (pad->getRocket() != nullptr)
            mRocket = pad->getRocket();
        mPad = pad;
    }
private:
    ///rocket
    std::shared_ptr<CRocket> mRocket = nullptr;

    ///rocket pad
    CTileRocketPad* mPad;
};

