#pragma once
#include "TileVisitor.h"
#include "TileRocketPad.h"

/**
 * visitor, check if a tile a rocketpad
 */
class CIsPadVisitor :
    public CTileVisitor
{
public:
    /** check if pad
 * \returns mIspad */
    bool ispad() { return mIspad;}

    /** check if pad
 * \returns mhasrocket */
    bool hasRocket() { return mHasRocket;}

    /**
*  get the pad
* \return mPad
*/
    CTileRocketPad* getPad() { return mPad; }
    /** Visit a CTileBuilding object
* \param pad Pad we are visiting */
    void VisitRocketPad(CTileRocketPad* pad)
    {
        mPad = pad;
        mIspad = true;
        if (pad->getRocket() != nullptr)
            mHasRocket = true;
    }
private:
    /// check if it is a pad
    bool mIspad = false;
    ///check if it has a rocket
    bool mHasRocket = false;
    ///mpad
    CTileRocketPad* mPad;

};