/**
 * \file CAnimal.cpp
 *
 * \author Haoyun Wu
 */
#include "CAnimal.h"
CAnimal::~CAnimal()
{
}