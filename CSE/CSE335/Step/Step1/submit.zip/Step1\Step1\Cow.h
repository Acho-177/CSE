/** Class that describes a cow.
*/
#pragma once
#include "CAnimal.h"
#include <string>
/** Class that describes a cow.
*/
class CCow : public CAnimal
{
	public:
        // CCow();
        // virtual ~CCow();

        /** display the animal in the farm
         *
         *
         */
        void DisplayAnimal();

        /// The types of cow we can have on our farm
		enum class Type { Bull, BeefCow, MilkCow };

        /** get cow's name
         *
         *\return string of name
         */
        std::string GetName() const { return mName; }

        /** set cow's name
        *
        *\param name
        */
        void SetName(const std::string& name) { mName = name; };

        /** get cow's information
         *
         *
         */
        void ObtainCowInformation();
    private:
        /// The cow's name
        std::string mName;

        /// The type of cow: Bull, BeefCow, or MilkCow
        Type mType = Type::MilkCow;

        /// The milk production for a cow in gallons per day
        double mMilkProduction = 0;
};

