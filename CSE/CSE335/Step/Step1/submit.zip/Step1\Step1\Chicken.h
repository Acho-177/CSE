/** Class that describes a chicken.
*/
#pragma once
#include <string>
#include "CAnimal.h"
/** Class that describes a cow.
*/
class CChicken : public CAnimal
{
public:
    /*
    *get the information of the duck
    */
    void ObtainChickenInformation();

    /*
    *display the animal
    */ 
    void DisplayAnimal();
    
private:
    /// The chicken's ID
    std::string mId;
};
