/** Class that describes a farm.
*/
#pragma once
#include <vector>
#include "Cow.h"
/** Class that describes a farm.
*/
class CFarm
{
    private:
        /// A list with the inventory of all animals on the farm
        std::vector<CAnimal*> mInventory;

    public:
        /** add animal to the farm
        *\param animal 
        *
        */
        void AddAnimal(CAnimal* animal);

        /** display the inventory
        *
        *
        */
        void DisplayInventory();

        /** count animal which has the same weight of witch
        *
        *\return number witchweight animal
        */
        int countanimal();
        ~CFarm();
};

