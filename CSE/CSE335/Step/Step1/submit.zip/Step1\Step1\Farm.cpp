/**
 * \file Farm.cpp
 *
 * \author Haoyun Wu
 */
#include "Farm.h"
#include "leak.h"
int CFarm::countanimal()
{
    int count = 0;
    for (auto animal : mInventory)
        if (animal->IsWeight()) count++;
    return count;
}
void CFarm::AddAnimal(CAnimal* animal)
{
    mInventory.push_back(animal);
}
void CFarm::DisplayInventory()
{
    for (auto animal : mInventory)
    {
        animal->DisplayAnimal();
    }
}
CFarm::~CFarm()
{
    // Iterate over all of the animals, destroying 
    // each one.
    for (auto animal : mInventory)
    {
        delete animal;
    }

    // And clear the list
    mInventory.clear();
}