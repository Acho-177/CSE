/** Class that describes a duck.
*/
#pragma once
#include <string>
#include "CAnimal.h"
/** Class that describes a duck.
*/
class CDuck : public CAnimal
{
public:
     //CCow();
     //virtual ~CCow();

    /** check the weight
    *
    *\return true if not Disney type
    */
    virtual bool IsWeight(){ return !(mType == Type::Disney); }

    /** display the animal in the farm
    *
    *
    */
    void DisplayAnimal();

    /// The types of duck we can have on our farm
    enum class Type { Mallard, Wood, Disney, Warner }; 

    /** get duck's name
    *
    *\return duck's name
    */
    std::string GetName() const { return mName; }

    /** get duck's name
    *\param name
    *
    */
    void SetName(const std::string& name) { mName = name; };

    /** get duck's information
    *
    *
    */
    void ObtainDuckInformation();
private:
    /// The duck's name
    std::string mName;

    /// The type of duck: Mallard, Wood, Disney, or Warner
    Type mType = Type::Mallard;
};