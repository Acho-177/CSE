#include "Duck.h"
#include "Cow.h"
#include "leak.h"
#include <iostream>
using namespace std;
void CDuck::ObtainDuckInformation()
{
    cout << endl;
    cout << "Input information about the duck" << endl;

    // Obtain the name. This is easy, since it's just a
    // string.
    cout << "Name: ";
    cin.ignore();
    getline(cin, mName);
    if (mName == "") { cout << "Invalid Name" <<endl; return;}
    else if (mName[0] == ' ') { cout << "Invalid Name" << endl; return;}

    // Obtain the type using a menu. We have a loop so
    // we can handle errors.
    bool valid = false;
    while (!valid)
    {
        cout << "1: Mallard Duck" << endl;
        cout << "2: Wood Duck" << endl;
        cout << "3: Disney Duck" << endl;
        cout << "4: Warner Brothers Duck" << endl;
        cout << "Enter selection and return: ";
        int option;
        cin >> option;
        if (!cin)
        {
            // We have an error. Clear the input and try again
            cin.clear();
            cin.ignore();
            continue;
        }

        switch (option)
        {
        case 1:
            mType = Type::Mallard;
            valid = true;
            break;

        case 2:
            mType = Type::Wood;
            valid = true;
            break;

        case 3:
            mType = Type::Disney;
            valid = true;
            break;

        case 4:
            mType = Type::Warner;
            valid = true;
            break;
        }
        
    }

}
void CDuck::DisplayAnimal()
{
    cout << mName << ": ";
    switch (mType)
    {
    case Type::Mallard:
        cout << "Mallard Duck" << endl;
        break;

    case Type::Wood:
        cout << "Wood Duck" << endl;
        break;

    case Type::Disney:
        cout << "Disney Duck" << endl;
        break;

    case Type::Warner:
        cout << "Warner Brothers Duck" << endl;
        break;
    }
}
