/** Class that describes a animal.
*/
#pragma once
#include <string>
/** Class that describes a cow.
*/
class CAnimal
{
public:
    virtual ~CAnimal();

    /** display the animal in the farm
     *
     *
     */
    virtual void DisplayAnimal() {}

    /** Open a file in the application and load it in.
     *
     * \return false default.
     */
    virtual bool IsWeight() { return false;}
};