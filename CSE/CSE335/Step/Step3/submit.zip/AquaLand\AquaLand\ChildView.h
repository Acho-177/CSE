﻿/**
 * \file ChildView.h
 *
 * \author Charles B. Owen
 *
 * Class that implements the child window our program draws in.
 *
 * The window is a child of the main frame, which holds this
 * window, the menu bar, and the status bar.
 */
// ChildView.h: CChildView 类的接口
//


#pragma once
#include "Aquarium.h"

// CChildView 窗口
/**
 * The child window our program draws in.
 */
class CChildView : public CWnd
{
private:
	/// An object that describes our aquarium
	CAquarium  mAquarium;

	/// Any item we are currently dragging
	std::shared_ptr<CItem> mGrabbedItem;

	/// True until the first time we draw
	bool mFirstDraw = true;

	long long mLastTime = 0;    ///< Last time we read the timer
	double mTimeFreq = 0;       ///< Rate the timer updates
// 构造
public:
	CChildView();

// 特性
public:

// 操作
public:

// 重写
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// 实现
public:
	virtual ~CChildView();

	// 生成的消息映射函数
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnAddfishBetafish();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnAddfishAngelfish();
	afx_msg void OnAddfishDoryfish();
	afx_msg void OnAdddecorAddcastle();
	afx_msg void OnFileSaveas32779();
	afx_msg void OnFileOpen32780();
	afx_msg void OnClearClear();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};

