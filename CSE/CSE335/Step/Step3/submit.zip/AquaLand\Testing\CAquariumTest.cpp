#include "pch.h"
#include "CppUnitTest.h"
#include "Aquarium.h"
#include <memory>
#include "FishBeta.h"
#include "FishDory.h"
#include "FishAngelfish.h"
#include "DecorCastle.h"
#include <regex>
#include <string>
#include <fstream>
#include <streambuf>
using namespace std;
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

/// Maximum speed in the X direction in
const double MaxSpeedX = 50;
/// Maximum speed in the Y direction in
const double MaxSpeedY = 50;

///RandomSeed
const unsigned int RandomSeed = 1238197374;

/**
* Create a path to a place to put temporary files
*/
wstring TempPath()
{
	// Create a path to temporary files
	wchar_t path_nts[MAX_PATH];
	GetTempPath(MAX_PATH, path_nts);

	// Convert null terminated string to wstring
	return wstring(path_nts);
}

/**
* Read a file into a wstring and return it.
* \param filename Name of the file to read
* \return File contents
*/
wstring ReadFile(const wstring& filename)
{
	ifstream t(filename);
	wstring str((istreambuf_iterator<char>(t)),
		istreambuf_iterator<char>());

	return str;
}

/**
* Test to ensure an aquarium .aqua file is empty
*/
void TestEmpty(wstring filename)
{
	Logger::WriteMessage(filename.c_str());

	wstring xml = ReadFile(filename);
	Logger::WriteMessage(xml.c_str());

	Assert::IsTrue(regex_search(xml, wregex(L"<\\?xml.*\\?>")));
	Assert::IsTrue(regex_search(xml, wregex(L"<aqua/>")));

}

/**
 *  Populate an aquarium with three Beta fish
 */
void PopulateThreeBetas(CAquarium* aquarium)
{
	shared_ptr<CFishBeta> fish1 = make_shared<CFishBeta>(aquarium);
	fish1->SetLocation(100, 200);
	aquarium->Add(fish1);

	shared_ptr<CFishBeta> fish2 = make_shared<CFishBeta>(aquarium);
	fish2->SetLocation(400, 400);
	aquarium->Add(fish2);

	shared_ptr<CFishBeta> fish3 = make_shared<CFishBeta>(aquarium);
	fish3->SetLocation(600, 100);
	aquarium->Add(fish3);
}

void TestThreeBetas(wstring filename)
{
	Logger::WriteMessage(filename.c_str());

	wstring xml = ReadFile(filename);
	Logger::WriteMessage(xml.c_str());

	// Ensure three items
	Assert::IsTrue(regex_search(xml, wregex(L"<aqua><item.*<item.*<item.*</aqua>")));

	// Ensure the positions are correct
	Assert::IsTrue(regex_search(xml, wregex(L"<item xLoc=\"100\" yLoc=\"200\"")));
	Assert::IsTrue(regex_search(xml, wregex(L"<item xLoc=\"400\" yLoc=\"400\"")));
	Assert::IsTrue(regex_search(xml, wregex(L"<item xLoc=\"600\" yLoc=\"100\"")));

	// Ensure the types are correct
	Assert::IsTrue(regex_search(xml,
		wregex(L"<aqua><item.* type=\"beta\"/><item.* type=\"beta\"/><item.* type=\"beta\"/></aqua>")));
}


/**
 *  Populate an aquarium with all type
 */
void PopulateAllTypes(CAquarium* aquarium)
{
	srand(RandomSeed);

	shared_ptr<CFishBeta> fish1 = make_shared<CFishBeta>(aquarium);
	fish1->SetLocation(100, 200);
	fish1->SetSpeedX(100);
	fish1->SetSpeedY(100);
	aquarium->Add(fish1);

	shared_ptr<CFishDory> fish2 = make_shared<CFishDory>(aquarium);
	fish2->SetLocation(400, 400);
	fish2->SetSpeedX(((double)rand() / RAND_MAX) * MaxSpeedX);
	fish2->SetSpeedY(((double)rand() / RAND_MAX) * MaxSpeedY);
	aquarium->Add(fish2);

	shared_ptr<CFishAngelfish> fish3 = make_shared<CFishAngelfish>(aquarium);
	fish3->SetLocation(600, 100);
	fish3->SetSpeedX(((double)rand() / RAND_MAX) * MaxSpeedX);
	fish3->SetSpeedY(((double)rand() / RAND_MAX) * MaxSpeedY);
	aquarium->Add(fish3);

	shared_ptr<CDecorCastle> item = make_shared<CDecorCastle>(aquarium);
	item->SetLocation(800, 200);
	aquarium->Add(item);
}

void TestAllTypes(wstring filename)
{
	Logger::WriteMessage(filename.c_str());

	wstring xml = ReadFile(filename);
	Logger::WriteMessage(xml.c_str());

	// Ensure four items
	Assert::IsTrue(regex_search(xml, wregex(L"<aqua><item.*<item.*<item.*<item.*</aqua>")));

	// Ensure the positions are correct
	Assert::IsTrue(regex_search(xml, wregex(L"<item xLoc=\"100\" yLoc=\"200\" xSpeed=\"100\" ySpeed=\"100\"")));
	Assert::IsTrue(regex_search(xml, wregex(L"<item xLoc=\"400\" yLoc=\"400\"")));
	Assert::IsTrue(regex_search(xml, wregex(L"<item xLoc=\"600\" yLoc=\"100\"")));
	Assert::IsTrue(regex_search(xml, wregex(L"<item xLoc=\"800\" yLoc=\"200\"")));

	// Ensure the types are correct
	Assert::IsTrue(regex_search(xml,
		wregex(L"<aqua><item.* type=\"beta\"/><item.* type=\"dory\"/><item.* type=\"angelfish\"/><item.* type=\"castle\"/></aqua>")));


}

namespace Testing
{

	TEST_CLASS(CAquariumTest)
	{
	public:

		TEST_METHOD_INITIALIZE(methodName)
		{
			extern wchar_t g_dir[];
			::SetCurrentDirectory(g_dir);
		}
		
		TEST_METHOD(TestCAquariumConstruct)
		{
			CAquarium aquarium;
			// This is an empty test just to ensure the system is working
		}

		TEST_METHOD(TestCAquariumHitTest)
		{
			CAquarium aquarium;

			Assert::IsTrue(aquarium.HitTest(100, 200) == nullptr,
				L"Testing empty aquarium");

			shared_ptr<CFishBeta> fish1 = make_shared<CFishBeta>(&aquarium);
			fish1->SetLocation(100, 200);
			aquarium.Add(fish1);

			Assert::IsTrue(aquarium.HitTest(100, 200) == fish1,
				L"Testing fish at 100, 200");
		}

		TEST_METHOD(TestCAquariumHitTestTOP)
		{
			CAquarium aquarium;

			Assert::IsTrue(aquarium.HitTest(100, 200) == nullptr,
				L"Testing empty aquarium");

			shared_ptr<CFishBeta> fish1 = make_shared<CFishBeta>(&aquarium);
			fish1->SetLocation(100, 200);
			aquarium.Add(fish1);
			shared_ptr<CFishBeta> fish2 = make_shared<CFishBeta>(&aquarium);
			fish2->SetLocation(100, 200);
			aquarium.Add(fish2);

			Assert::IsTrue(aquarium.HitTest(100, 200) == fish2,
				L"Testing finds the image on top");
		}

		TEST_METHOD(TestCAquariumHitTest2)
		{
			CAquarium aquarium;

			Assert::IsTrue(aquarium.HitTest(100, 200) == nullptr,
				L"Testing empty aquarium");

			shared_ptr<CFishBeta> fish1 = make_shared<CFishBeta>(&aquarium);
			fish1->SetLocation(100, 200);
			aquarium.Add(fish1);

			Assert::IsTrue(aquarium.HitTest(10, 200) == nullptr,
				L"Testing empty aquarium");
			
		}

		TEST_METHOD(TestCAquariumSave)
		{
			// Create a path to temporary files
			wstring path = TempPath();

			// Create an aquarium
			CAquarium aquarium;

			//
			// First test, saving an empty aquarium
			//
			wstring file1 = path + L"test1.aqua";
			aquarium.Save(file1);

			TestEmpty(file1);

			//
			// Now populate the aquarium
			//

			PopulateThreeBetas(&aquarium);

			wstring file2 = path + L"test2.aqua";
			aquarium.Save(file2);

			TestThreeBetas(file2);

			//
			// Test all types
			//
			srand(RandomSeed);
			CAquarium aquarium3;
			PopulateAllTypes(&aquarium3);

			wstring file3 = path + L"test3.aqua";
			aquarium3.Save(file3);

			TestAllTypes(file3);
		}

		TEST_METHOD(TestCAquariumClear)
		{
			CAquarium aquarium;

			shared_ptr<CFishBeta> fish1 = make_shared<CFishBeta>(&aquarium);
			fish1->SetLocation(100, 200);
			aquarium.Add(fish1);

			Assert::IsFalse(aquarium.HitTest(100, 200) == nullptr,
				L"Testing empty aquarium");

			aquarium.Clear();

			Assert::IsTrue(aquarium.HitTest(100, 200) == nullptr,
				L"Testing empty aquarium");

		}

		TEST_METHOD(TestCAquariumLoad)
        {
            // Create a path to temporary files
            wstring path = TempPath();

            // Create two aquariums
            CAquarium aquarium, aquarium2;

            //
            // First test, saving an empty aquarium
            //
            wstring file1 = path + L"test1.aqua";

            aquarium.Save(file1);
            TestEmpty(file1);

            aquarium2.Load(file1);
            aquarium2.Save(file1);
            TestEmpty(file1);

            //
            // Now populate the aquarium
            //

            PopulateThreeBetas(&aquarium);

            wstring file2 = path + L"test2.aqua";
            aquarium.Save(file2);
            TestThreeBetas(file2);

            aquarium2.Load(file2);
            aquarium2.Save(file2);
            TestThreeBetas(file2);

            //
            // Test all types
            //
            CAquarium aquarium3;
            PopulateAllTypes(&aquarium3);

            wstring file3 = path + L"test3.aqua";
            aquarium3.Save(file3);
            TestAllTypes(file3);

            aquarium2.Load(file3);
            aquarium2.Save(file3);
            TestAllTypes(file3);
        }
	};
}
