#pragma once
#include <string>
#include "Item.h"
/**
 * Base class for a fish
 * This applies to all of the fish, but not the decor
 * items in the aquarium.
 */
class CFish :
    public CItem
{
public:
    /// Default constructor (disabled)
    CFish() = delete;

    /// Copy constructor (disabled)
    CFish(const CFish&) = delete;


    virtual std::shared_ptr<xmlnode::CXmlNode>
        XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    void Update(double elapsed);

    /**
     * set the speedX
     * \param speed
     */
    void SetSpeedX(double speed) { mSpeedX = speed; }

    /**
     * set the speedY
     * \param speed
     */
    void SetSpeedY(double speed) { mSpeedY = speed; }

    /**
     * get the speedX
     * \return SpeedX
     */
    double getSpeedX() { return mSpeedX; }

    /**
     * get the speedY
     * \return SpeedY
     */
    double getSpeedY() { return mSpeedX; }

protected:
    CFish(CAquarium* aquarium, const std::wstring& filename);

private:
    /// Fish speed in the X direction
    double mSpeedX;

    /// Fish speed in the Y direction
    double mSpeedY;
};

