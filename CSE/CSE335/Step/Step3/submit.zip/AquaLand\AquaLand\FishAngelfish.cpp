/**
 * \file FishAngelfish.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include <string>
#include "FishAngelfish.h"
using namespace std;
using namespace Gdiplus;

/// Fish filename 
const wstring FishAngelImageName = L"images/angelfish.png";

///MinSpeedX
const double MinSpeedX = 40;
///MaxSpeedX
const double MaxSpeedX = 80;
///MinSpeedY
const double MinSpeedY = 20;
///MaxSpeedY
const double MaxSpeedY = 50;

/** Constructor
 * \param aquarium The aquarium this is a member of
*/
CFishAngelfish::CFishAngelfish(CAquarium* aquarium) :
    CFish(aquarium, FishAngelImageName)
{
    CFish::SetSpeedX(MinSpeedX + ((double)rand() / RAND_MAX) * (MaxSpeedX - MinSpeedX));
    CFish::SetSpeedY(MinSpeedY + ((double)rand() / RAND_MAX) * (MaxSpeedY - MinSpeedY));
}


/**
* Save this item to an XML node
* \param node The node we are going to be a child of
* \return the document
*/
std::shared_ptr<xmlnode::CXmlNode>
CFishAngelfish::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CFish::XmlSave(node);
    itemNode->SetAttribute(L"type", L"angelfish");
    return itemNode;
}
