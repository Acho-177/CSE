/**
 * \file Aquarium.h
 *
 * \author Charles B. Owen
 *
 * Class that represents an aquarium.
 */
#pragma once

#include <memory>
#include <vector>
#include <string>
#include "XmlNode.h"
#include "Item.h"
using namespace xmlnode;
class CItem;

/**
 * Represents an aquarium
 */
class CAquarium
{
public:
    CAquarium();

    void OnDraw(Gdiplus::Graphics* graphics);

    void Add(std::shared_ptr<CItem> item);

    void pushBack(std::shared_ptr<CItem> item);

    double Distance(std::shared_ptr<CItem> item1, std::shared_ptr<CItem> item2);
    //int size() { return mItems.size(); }

    //HITTEST
    std::shared_ptr<CItem> HitTest(int x, int y);


    /**
 * Save the aquarium as a .aqua XML file.
 *
 * Open an XML file and stream the aquarium data to it.
 *
 * \param filename The filename of the file to save the aquarium to
 */
    void CAquarium::Save(const std::wstring& filename)
    {
        //
        // Create an XML document
        //
        auto root = CXmlNode::CreateDocument(L"aqua");

        // Iterate over all items and save them
        for (auto item : mItems)
        {
            item->XmlSave(root);
        }

        try
        {
            root->Save(filename);
        }
        catch (CXmlNode::Exception ex)
        {
            AfxMessageBox(ex.Message().c_str());
        }
    }

    void Load(const std::wstring& filename);
    void Clear();
    void XmlItem(const std::shared_ptr<xmlnode::CXmlNode>& node);
    void Update(double elapsed);

    /// Get the width of the aquarium
    /// \returns Aquarium width
    int GetWidth() const { return mBackground->GetWidth(); }

    /// Get the height of the aquarium
    /// \returns Aquarium height
    int GetHeight() const { return mBackground->GetHeight(); }
private:
    std::unique_ptr<Gdiplus::Bitmap> mBackground; ///< Background image to use

    /// All of the items to populate our aquarium
    std::vector<std::shared_ptr<CItem> > mItems;
};
