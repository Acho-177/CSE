#include "pch.h"
#include "Fish.h"
#include "Aquarium.h"
#include "Item.h"
///speed change rate
const double SpeedChangeRate = 1.5;

/// Maximum speed in the X direction in
/// in pixels per second
const double MaxSpeedX = 50;

/// Maximum speed in the Y direction in
/// in pixels per second
const double MaxSpeedY = 50;

///BOUNDARY
const double distance = 10;

///SPEEDLIMIT
const double speedlimit = 250;



/**
 * Constructor
 * \param aquarium The aquarium we are in
 * \param filename Filename for the image we use
 */
CFish::CFish(CAquarium* aquarium, const std::wstring& filename) :
    CItem(aquarium, filename)
{
    mSpeedX = ((double)rand() / RAND_MAX) * MaxSpeedX;
    mSpeedY = ((double)rand() / RAND_MAX) * MaxSpeedY;
}

/**
 * save the document
 * \param node
 * \return itemNode
 */
std::shared_ptr<xmlnode::CXmlNode> CFish::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);
    itemNode->SetAttribute(L"xLoc", CItem::GetX());
    itemNode->SetAttribute(L"yLoc", CItem::GetY());
    itemNode->SetAttribute(L"xSpeed", mSpeedX);
    itemNode->SetAttribute(L"ySpeed", mSpeedY);
    return itemNode;
}

/**
 * load the document
 * \param node
 */
void CFish::XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    CItem::XmlLoad(node);
    mSpeedX = node->GetAttributeDoubleValue(L"xSpeed", 0);
    mSpeedY = node->GetAttributeDoubleValue(L"ySpeed", 0);
    SetMirror(mSpeedX < 0);
}

/**
 * Handle updates in time of our fish
 *
 * This is called before we draw and allows us to
 * move our fish. We add our speed times the amount
 * of time that has elapsed.
 * \param elapsed Time elapsed since the class call
 */
void CFish::Update(double elapsed)
{

    SetLocation(GetX() + mSpeedX * elapsed,
        GetY() + mSpeedY * elapsed);

    if ( mSpeedX > 0 && GetX() >= GetAquarium()->GetWidth() - distance- (float)CFish::GetWidth()/2)
    {
        mSpeedX = -mSpeedX * SpeedChangeRate;
        SetMirror(mSpeedX < 0);
    }

    if ( mSpeedX < 0 && GetX() <= distance + (float)CFish::GetWidth()/2)
    {
        mSpeedX = -mSpeedX * SpeedChangeRate;
        SetMirror(mSpeedX < 0);
    }

    if (speedlimit > mSpeedY > 0 && GetY() >= GetAquarium()->GetHeight() - distance- (float)CFish::GetHeight()/2)
    {
        mSpeedY = -mSpeedY;
    }

    if (mSpeedY < 0 && GetY() <= distance + (float)CFish::GetHeight()/2)
    {
        mSpeedY = -mSpeedY;
    }

    if (mSpeedX > speedlimit)
    {
        mSpeedX = speedlimit;
    }
    if (mSpeedX < -speedlimit)
    {
        mSpeedX = -speedlimit;
    }
}