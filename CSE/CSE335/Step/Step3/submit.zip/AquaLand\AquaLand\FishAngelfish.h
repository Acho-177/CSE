/**
 * \file FishAngelfish.h
 *
 * \author Charles B. Owen
 *
 * Class the implements a Beta fish
 */

#pragma once

#include <memory>
#include "XmlNode.h"
#include "Item.h"
#include "Fish.h"

 /**
  * Implements a Angelfish
  */
class CFishAngelfish : public CFish
{
public:
    CFishAngelfish(CAquarium* aquarium);

    /// Default constructor (disabled)
    CFishAngelfish() = delete;

    /// Copy constructor (disabled)
    CFishAngelfish(const CFishAngelfish&) = delete;

    virtual std::shared_ptr<xmlnode::CXmlNode>
        XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

private:
};