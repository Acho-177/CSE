/**
 * \file FishDory.cpp
 *
 * \author Charles B. Owen
 */

#include "pch.h"
#include <string>
#include "FishDory.h"
using namespace std;
using namespace Gdiplus;

/// Fish filename 
const wstring FishDoryImageName = L"images/Dory.png";

///MinSpeedX
const double MinSpeedX = 20;
///MaxSpeedX
const double MaxSpeedX = 40;
///MinSpeedY
const double MinSpeedY = 20;
///MaxSpeedY
const double MaxSpeedY = 40;

/** Constructor
 * \param aquarium The aquarium this is a member of
*/
CFishDory::CFishDory(CAquarium* aquarium) :
    CFish(aquarium, FishDoryImageName)
{
    CFish::SetSpeedX(MinSpeedX + ((double)rand() / RAND_MAX) * (MaxSpeedX - MinSpeedX));
    CFish::SetSpeedY(MinSpeedY + ((double)rand() / RAND_MAX) * (MaxSpeedY - MinSpeedY));
}


/**
* Save this item to an XML node
* \param node The node we are going to be a child of
* \return the document
*/
std::shared_ptr<xmlnode::CXmlNode>
CFishDory::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CFish::XmlSave(node);
    itemNode->SetAttribute(L"type", L"dory");
    return itemNode;
}