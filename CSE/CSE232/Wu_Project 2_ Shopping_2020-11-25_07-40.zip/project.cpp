#include <string>
using std::string;
#include <vector>
using std::vector;
#include <iostream>
using std::cout;using std::cin;
using std::endl;
#include <map>
using std::map;
using std::pair;
#include <sstream>
#include <iomanip>
using std::fixed;
#include <algorithm>

//build a struct to save all the data
struct shop_infor
{
  string shop_name = "";
  string loc = "";
  vector<vector<string>> item_inventory_price{};
};

bool isnum(char c) {return (c <= '9' && c>='0');}
bool cmp(string str1,string str2)
{
  if (str1.length() != str2.length()) return false;
  for (int i = 0; i < int(str1.length()); i++)
    if (str1[i] != str2[i]) return false;
  return true;
}

//get the best price
double get_optprice(const pair<string,int> &p,const vector<shop_infor> &v)
{
  double optprice = 0;
  int amount = p.second;
  vector<shop_infor> shop_with_targetitem{};
  vector<pair<string,int>> item_done{};

  //collect the information about the stores which have the item we want
  for (auto e1: v)
    for (auto e2: e1.item_inventory_price)
    {
      if (cmp(e2[0],p.first)) 
      {
        shop_infor s{};
        s.shop_name = e1.shop_name;
        s.loc = e1.loc;
        s.item_inventory_price.push_back(e2);
        shop_with_targetitem.push_back(s);
      }
    }
  
  //sort the information by the price
  sort(shop_with_targetitem.begin(),shop_with_targetitem.end(), 
      [] (shop_infor val1, shop_infor val2)
      {return stod(val1.item_inventory_price[0][2].substr(1)) < stod(val2.item_inventory_price[0][2].substr(1));});

  cout << shop_with_targetitem.size() <<" store(s) sell " << p.first <<".\n";


  //get the item 
  for (int i = 0; i < int(shop_with_targetitem.size()) && amount != 0; i++)
  {
    if (stoi(shop_with_targetitem[i].item_inventory_price[0][1]) == 0) {continue;}
    else 
    {
        if (amount > stoi(shop_with_targetitem[i].item_inventory_price[0][1])) 
        {
          optprice += stod(shop_with_targetitem[i].item_inventory_price[0][2].substr(1)) * stoi(shop_with_targetitem[i].item_inventory_price[0][1]);
          pair<string,int> p = make_pair (shop_with_targetitem[i].shop_name + " in " + shop_with_targetitem[i].loc,stoi(shop_with_targetitem[i].item_inventory_price[0][1]));
          item_done.push_back(p);
          amount -= stoi(shop_with_targetitem[i].item_inventory_price[0][1]);
        }
        else 
        {
          optprice += stod(shop_with_targetitem[i].item_inventory_price[0][2].substr(1)) * amount;
          pair<string,int> p = make_pair(shop_with_targetitem[i].shop_name + " in " + shop_with_targetitem[i].loc, amount );
          item_done.push_back(p);
          break;
        }//if the inventory can not meet the requirement, move to the next store, otherwise break the loop
    }
  }

  cout<<fixed<<std::setprecision(2);
  cout << "Total price: $" << optprice << endl;
  for (auto e:item_done)
    cout << "Order " << e.second << " from " << e.first << endl;

  return optprice;
}

//get the item's name, inventory, and price
vector<string> get_infor(string str)
{
  vector<string> v;
  string line;
  std::istringstream ss(str);
  while(getline(ss,line,',')) 
     v.push_back(line);
  return v;
}

void get_infor(vector<shop_infor> &v,vector<pair<string,int>> &total_price)
{
  string infor = "";
  int count = 0;
  int t = 0;

  getline(cin,infor);
  cout << "Store Related Information (ordered by in-file order):" <<endl;
  cout << "There are " << infor[0] <<" store(s)." << endl;

  //get the information of all the stores
  while(getline(cin,infor))
  {
    if (isnum(infor[0])) break;

    shop_infor shop;
    if (infor == "") {count = 0; t++;continue;}
    if (count == 0) v.push_back(shop);
    count ++;
    if (count == 1) {v[t].shop_name = infor;}
    else if (count == 2) {v[t].loc = infor;}
         else 
         {
           vector<string> vec = get_infor(infor);
           v[t].item_inventory_price.push_back(vec);
         }
  }

  //get the shopping list
  int shopping_list_num = int(infor[0]-48);
  for (int i = 0; i < shopping_list_num; i++)
  {
    getline(cin,infor);
    int pos = distance(infor.begin(),find_if(infor.begin(),infor.end(),[](char c){ return c == ' ';} ));
    int item_num = stoi(infor.substr(0,pos));
    string item_name = infor.substr(pos+1);
    pair<string,int> p = make_pair(item_name,item_num);
    total_price.push_back(p);
  }
}

//print the shop's information
void print_shop_infor(const vector<shop_infor> &v)
{
  map<string,int> items;

  for (auto e: v)  
  {
    cout << e.shop_name << " has " << e.item_inventory_price.size() << " distinct items.\n";
    for (auto e2:e.item_inventory_price)  items[e2[0]] += stoi(e2[1]);
  }

  cout << "\nItem Related Information (ordered alphabetically):\n";
  cout << "There are "<< items.size() <<" distinct item(s) available for purchase.\n";

  for (auto e: items) cout << "There are " << e.second << ' ' << e.first << "(s).\n";
}

//print the process of shopping
void print_shopping(const vector<pair<string,int>> &m,const vector<shop_infor> &v)
{
  double price = 0.0;
  cout << "\nShopping:\n";
  for (auto e:m)
  {
    cout << "Trying to order " << e.second << ' ' << e.first << "(s).\n";
    price += get_optprice(e,v);
  }
  cout<<fixed<<std::setprecision(2);
  cout << "\nBe sure to bring $" << price << " when you leave for the stores.\n";
}

int main()
{
  vector<shop_infor> v{}; 
  vector<pair<string,int>> total_price{};
  get_infor(v,total_price);
  print_shop_infor(v);
  print_shopping(total_price,v);
}