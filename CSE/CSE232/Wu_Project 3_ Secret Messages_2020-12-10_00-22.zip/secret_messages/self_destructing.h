#ifndef SELF_DESTRUCTING_H
#define SELF_DESTRUCTING_H

#include <stdexcept>
#include <string>
using std::string;
#include <vector>
using std::vector;
#include <ios>


class SelfDestructingMessage {
    public:
        SelfDestructingMessage();
        SelfDestructingMessage(vector<string>,long);
        SelfDestructingMessage(SelfDestructingMessage &);
        int size();
        int number_of_views_remaining(int index);
        vector<string> get_redacted();
        string operator[](int index)
        {
            if ((index >= messages.size()) or index < 0) throw std::out_of_range("");
            if (messages_allowed_views[index] <= 0) throw std::invalid_argument("");
            messages_allowed_views[index]--;
            return messages[index];
        }
        auto operator=(SelfDestructingMessage& sdm)
        {
            this -> messages = sdm.messages;
            this -> number_of_allowed_views = sdm.number_of_allowed_views;
            this -> messages_allowed_views = sdm.messages_allowed_views;
            sdm.messages = sdm.get_redacted();
            sdm.number_of_allowed_views = 0;
            for (int i = 0; i < sdm.size(); i++) sdm.messages_allowed_views[i] = 0;
        }
        void add_array_of_lines(string[],long);
        long number_of_allowed_views;
        vector<int> messages_allowed_views;
    private:
        vector<string> messages;
};


#endif
