#include "redact.h"
bool cmp(const char &c)
{
    if (((c>='0') && (c<='9')) or ((c>='a') && (c<='z')) or ((c>='A') && (c<='Z'))) return true;
    return false;
}

string redact_all_chars(const string& str)
{
    string res{};
    for (int i = 0; i < str.length(); i++) res+="#";
    return res;
}

string redact_alphabet_digits(const string& str)
{
    string res{};
    for (int i = 0; i < str.length(); i++) 
        if (cmp(str[i])) res += "#";
        else res += str[i];
    return res;
}

string redact_words(const string& str, const vector<string>& words)
{
    string res = str;
    for (int i = 0; i < words.size(); i++)
    {
        string str;
        str.assign(words[i].length(),'#');
        int pos = res.find(words[i]);
        while (pos != string::npos)
        {
            res = res.replace(pos,words[i].length(),str);
            pos = res.find(words[i]);
        }
    }
    return res;
}