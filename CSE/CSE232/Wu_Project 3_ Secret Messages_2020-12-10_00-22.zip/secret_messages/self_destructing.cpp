
#include "self_destructing.h"
#include "redact.h"
#include <sstream>

SelfDestructingMessage::SelfDestructingMessage()
{
    this -> messages = {};
    this -> number_of_allowed_views = 0;

}
SelfDestructingMessage::SelfDestructingMessage(vector<string> messages,long number_of_allowed_views)
{
    this -> messages = messages;
    this -> number_of_allowed_views = number_of_allowed_views;
    vector<int> v;
    for (int i = 0; i < messages.size(); i++)
        v.push_back(number_of_allowed_views);
    this -> messages_allowed_views = v;
}
SelfDestructingMessage::SelfDestructingMessage(SelfDestructingMessage &sdm)
{
    this -> messages = sdm.messages;
    this -> number_of_allowed_views = sdm.number_of_allowed_views;
    this -> messages_allowed_views = sdm.messages_allowed_views;
    sdm.messages = sdm.get_redacted();
    sdm.number_of_allowed_views = 0;
    for (int i = 0; i < sdm.size(); i++) sdm.messages_allowed_views[i] = 0;
}
int SelfDestructingMessage::size()
{
    return messages.size();
}
int SelfDestructingMessage::number_of_views_remaining(int index)
{
    return messages_allowed_views[index];
}

vector<string> SelfDestructingMessage::get_redacted()
{
    vector<string> res;
    for (auto e:this -> messages) res.push_back(redact_alphabet_digits(e));
    return res;
}

std::ostream &operator<<(std::ostream &out,SelfDestructingMessage &sdm)
{
    vector<string> tmp = sdm.get_redacted();
    for (int i = 0; i < tmp.size(); i++)
    {
        string str = std::to_string(sdm.number_of_views_remaining(i));
        if (str.size() < 2) str = "0" + str;
        out << str + ": " + tmp[i] + "\n";
    }
    return out;
}

void SelfDestructingMessage::add_array_of_lines(string str[],long len)
{
    for (int i = 0; i < len;i++)
    {
        this -> messages.push_back(str[i]);
        this -> messages_allowed_views.push_back(this -> number_of_allowed_views);
    }
}

void operator>>(std::stringstream &in,SelfDestructingMessage &sdm)
{
    string str[]{in.str()};
    sdm.add_array_of_lines(str,1);
    sdm.messages_allowed_views.push_back(sdm.number_of_allowed_views);
}