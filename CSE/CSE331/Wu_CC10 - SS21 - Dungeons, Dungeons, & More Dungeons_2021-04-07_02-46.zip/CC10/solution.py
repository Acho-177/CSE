"""
Haoyun Wu
Coding Challenge 10
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from CC10.game import Game


def count_good_dungeons(game: Game) -> int:
    """
    Count good dungeons
    The function should return a count of how many good subgraphs (dungeons) the Game graph as a whole contains.
    game: Graph: A graph that stores the subgraphs (dungeons) to check.
    Return: An integer that represents the count of how many good dungeons were found
    """
    cnt = 0
    cycle = [False]
    visited, all_visited = set(), set()
    path = []

    def count_helper(current_room, target_room):
        path.append(current_room)
        visited.add(current_room.room_id)
        connect_room = current_room.adjacent_rooms
        for room in connect_room:
            if room != target_room and room in path:
                cycle[0] = True
            if room.room_id not in visited:
                count_helper(room, current_room)

    for room in game.rooms:
        if room.room_id not in all_visited:
            count_helper(room, room)
        all_visited.update(visited)
        cnt += 1 if cycle[0] else 0
        path, visited, cycle = [], set(), [False]
    return cnt
