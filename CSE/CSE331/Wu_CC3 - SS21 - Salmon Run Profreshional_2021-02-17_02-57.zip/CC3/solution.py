"""
Haoyun Wu
Coding Challenge 3
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import List


def finding_best_bot(bots_list: List[int]) -> int:
    """
    using recursion find the best bot
    """
    length = len(bots_list) - 1

    def finding_best_bot_helper(start: int, end: int):
        """
        Fill out this doc-string
        """
        if start < end:
            mid = (start + end)//2
            if bots_list[mid] < bots_list[mid+1]:
                start = mid + 1
            else:
                end = mid
            return finding_best_bot_helper(start, end)
        return start

    return finding_best_bot_helper(0, length) + 1
