"""
Name
Coding Challenge 1 - Love Is In The Air
CSE 331 Spring 2021
Professor Sebnem Onsay
"""



def story_progression(list_ans, list_que):
    """
    Determine if each tuple in the question list to check that range of the answer list
    to determine if that chunk results in a win or a loss for the player.
    It will be a win condition if the chunk contains a majority
    :param answers: list of 0’s and 1’s, 1 represents a correct choice, 0 otherwise
    :param questions: list of questions, is a list of tuple of length 2, where
           Element [0] is starting index of the interested range
           Element [1] is ending index of the interested range
    :return: A Python list of the same length as list of question,
            each element is either “Win” or “Lose,”
    """
    res = []
    check = 0
    if len(list_que) == 0:
        return res
    for i in range(0, len(list_que)):
        if 0 < i < len(list_que)-1:
            if list_que[i] == list_que[i-1]:
                if check > 0:
                    res.append('Win')
                    continue
                res.append('Lose')
                continue
        check = 0
        if list_que[i][0] == list_que[i][1]:
            check = list_ans[list_que[i][0]]
            if check > 0:
                res.append('Win')
            else:
                res.append('Lose')
            continue
        for j in range(list_que[i][0], list_que[i][1]+1):
            if list_ans[j] == 1:
                check += 1
            else:
                check -= 1
        if check > 0:
            res.append('Win')
            continue
        res.append('Lose')
    return res
