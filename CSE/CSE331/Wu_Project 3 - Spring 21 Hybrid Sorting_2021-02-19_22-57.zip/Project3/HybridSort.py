"""
Name: Haoyun Wu
Project 3 - Hybrid Sorting
Developed by Sean Nguyen and Andrew Haas
Based on work by Zosha Korzecke and Olivia Mikola
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import TypeVar, List, Callable
import copy
import math

T = TypeVar("T")            # represents generic type


def merge_sort(data: List[T], threshold: int = 0,
               comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> int:
    """
    REPLACE
    """
    length = len(data)

    if length < 2:
        return 0
    if length < threshold:
        insertion_sort(data, comparator)
        return 0

    mid = length // 2
    left = data[:mid]
    right = data[mid:]

    inversion = 0
    inversion += merge_sort(left, threshold, comparator)
    inversion += merge_sort(right, threshold, comparator)

    i = j = 0

    while i + j < length:
        if j == len(right) or ((i < len(left)) and comparator(left[i], right[j])):
            data[i+j] = left[i]
            i += 1
        else:
            data[i+j] = right[j]
            inversion += mid - i
            j += 1

    return inversion


def insertion_sort(data: List[T], comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    REPLACE
    """
    for i in range(1, len(data)):
        key = data[i]
        j = i - 1
        while j >= 0 and comparator(key, data[j]):
            data[j+1] = data[j]
            j -= 1
        data[j+1] = key


def hybrid_sort(data: List[T], threshold: int,
                comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    REPLACE
    """
    merge_sort(data, threshold, comparator)


def inversions_count(data: List[T]) -> int:
    """
    REPLACE
    """
    return merge_sort(copy.deepcopy(data))


def reverse_sort(data: List[T], threshold: int) -> None:
    """
    REPLACE
    """
    merge_sort(data, threshold, comparator=lambda x, y: x >= y)


def password_rate(password: str) -> float:
    """
    REPLACE
    """
    unq = []
    data = []

    for item in password:
        if item not in unq:
            unq.append(item)
        data.append(item)

    return math.sqrt(len(password)) * math.sqrt(len(unq)) + inversions_count(data)


def password_sort(data: List[str]) -> None:
    """
    REPLACE
    """
    reslist = []
    for password in data:
        reslist.append((password, password_rate(password)))

    merge_sort(reslist, 0, comparator=lambda a, b: a[1] > b[1])

    for i in range(0, len(reslist)):
        data[i] = reslist[i][0]
