"""
Haoyun Wu
Coding Challenge 5
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import List


def check_walls_cover(walls: List[int]) -> List[int]:
    """
    Please fill out this doc-string
    """
    def find_wall(lst: List[int]) -> List[int]:
        res = []
        for i in range(len(lst)):
            res.append(None)
        stack = []
        for i in range(len(lst)):
            while len(stack) > 0 and stack[-1] <= lst[i]:
                stack.pop()
            res[i] = len(stack)
            stack.append(lst[i])
        return res

    res_left = find_wall(walls)
    walls.reverse()
    res_right = find_wall(walls)

    res_total = []
    for i in range(len(walls)):
        res_total.append(res_left[i] + res_right[-i-1])
    return res_total
