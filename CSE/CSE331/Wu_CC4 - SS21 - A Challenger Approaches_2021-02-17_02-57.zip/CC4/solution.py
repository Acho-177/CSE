"""
Haoyun Wu
Coding Challenge 4
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import List


def challenger_finder(stocks_list: List[int], k: int) -> List[int]:
    """
    find the number of member in the match range
    """
    checklist = sorted(stocks_list)
    res = []
    length = len(stocks_list)

    def low_bound(start: int, end: int, player: int):
        while start < end:
            mid = start + (end - start) // 2
            if checklist[mid] < player - k:
                start = mid + 1
            else:
                end = mid
        return start

    def up_bound(start: int, end: int, player: int):
        while start < end:
            mid = start + (end - start) // 2
            if checklist[mid] > k + player:
                end = mid
            else:
                start = mid + 1
        return start

    # def finder(start: int, end: int, player: int):
    #    count = -1
    #    for j in range(0, len(checklist)):
    #        if abs(checklist[j] - player) <= k:
    #            count += 1
    #    return count
    #
    #   if j > length:
    #        return 0
    #    if abs(checklist[j] - player) <= k:
    #        return 1 + finder(j+1, player)
    #    return finder(j+1, player)
    #    pass

    for i in stocks_list:
        res.append(up_bound(0, length, i) - low_bound(0, length, i)-1)
    return res


