"""
Name: Haoyun Wu
Coding Challenge 9
CSE 331 Spring 2021
Professor Sebnem Onsay
"""

from typing import List, Tuple


class Dungeon:
    """
    Represents a dungeon made of rooms connected by hallways
    Implemented as an adjacency matrix
    """

    __slots__ = ['adjacency_matrix']

    def __init__(self, rooms: List[int], hallways: List[Tuple[int, int]]) -> None:
        self.adjacency_matrix = [[0] * len(rooms) for _ in range(len(rooms))]
        for hall in hallways:
            self._add_connecting_hallway(*hall)

    def _add_connecting_hallway(self, start_room: int, end_room: int) -> None:
        """
        Adds a hallway to the dungeon
        :param start_room: start room
        :param end_room: end room
        :return: None
        """
        self.adjacency_matrix[start_room][end_room] = self.adjacency_matrix[end_room][start_room] = 1

    def get_connecting_rooms(self, current_room: int) -> List[int]:
        """
        Gets a list of rooms connected to the current room
        :param current_room: current room represented by an index in the matrix
        :return: List of connected, adjacent rooms
        """
        connecting_rooms = []
        for connected_room, required_stamina in enumerate(self.adjacency_matrix[current_room]):
            if required_stamina > 0:
                connecting_rooms.append(connected_room)
        return connecting_rooms

    def get_required_stamina(self, start_room: int, end_room: int) -> int:
        """
        Gets the required stamina between two edges
        :param start_room: First room at the end of a hallway
        :param end_room: Second room at the other end of a hallway
        :return: Stamina of hallway as an int
            will be 1 if the rooms are connected by a single hallway,
            0 if the rooms are not connected by a single hallway
        """
        return self.adjacency_matrix[start_room][end_room]


def dungeon_escape(dungeon: Dungeon, start_room: int, end_room: int,
                   stamina_limit: int) -> Tuple[List[int], int]:
    """
    Find a path from a start room to an end room while only crossing through a limited amount of rooms.
    dungeon: Dungeon: The dungeon you are trying to escape
    start_room: int: The starting room of your dungeon,
        this integer directly correlates to an index in the adjacency_matrix of dungeon
    end_room: int: The end room of your dungeon,
        this integer directly correlates to an index in the adjacency_matrix of dungeon
    stamina_limit: int:  The max amount of stamina you can use when trying to escape the dungeon.
        This is NOT the number of rooms you pass through,
        rather the number of hallways passed to get to your exit.
    Return: A tuple where the list of integers is your path,
        where the integers refer to rooms in your dungeon,
        and an integer representing the length (stamina used) of the path
    """
    visited = dict()
    main_stack = [start_room]
    visited[start_room] = True
    side_stack = [dungeon.get_connecting_rooms(start_room)]

    while main_stack:

        if len(main_stack) > 0 and main_stack[-1] == end_room:
            if len(main_stack) - 1 <= stamina_limit:
                return main_stack, len(main_stack) - 1
            visited[main_stack.pop()] = False
            if side_stack:
                side_stack.pop()

        side_top = side_stack.pop()

        if len(side_top) > 0:

            main_top = side_top[0]
            main_stack.append(main_top)
            visited[main_top] = True
            side_stack.append(side_top[1:])

            side_top = []
            for v in dungeon.get_connecting_rooms(main_top):
                try:
                    if not visited[v]:
                        side_top.append(v)
                except KeyError:
                    side_top.append(v)
            side_stack.append(side_top)
        else:
            visited[main_stack.pop()] = False

    return [], 0
