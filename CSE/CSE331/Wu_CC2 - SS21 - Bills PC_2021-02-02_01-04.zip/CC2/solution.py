"""
Name
Coding Challenge 2
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import List, Tuple
from CC2.linked_list import DLLNode, LinkedList


def pokemon_machine(pokemon: LinkedList, orders: List[Tuple]) -> LinkedList:
    """
    """
    def add_pokemon(cur_node: DLLNode, added_pokemon: str) -> None:
        """
        """
        node = DLLNode(added_pokemon)
        if cur_node == pokemon.head:
            node.prev = cur_node
            node.nxt = cur_node.nxt
            if cur_node.nxt:
                cur_node.nxt.prev = node
            else:
                pokemon.tail = node
            cur_node.nxt = node
        elif cur_node == pokemon.tail:
            cur_node.nxt = node
            node.prev = cur_node
            pokemon.tail = node
        else:
            node.prev = cur_node
            node.nxt = cur_node.nxt
            if cur_node.nxt:
                cur_node.nxt.prev = node
            else:
                pokemon.tail = node
            cur_node.nxt = node

    def remove_pokemon(cur_node: DLLNode) -> None:
        """
        """
        if cur_node is pokemon.head:
            if cur_node.nxt.nxt:
                cur_node.nxt.nxt.prev = cur_node
            cur_node.nxt = cur_node.nxt.nxt
        elif cur_node is pokemon.tail:
            cur_node.prev.nxt = None
            pokemon.tail = cur_node.prev
        else:
            cur_node.nxt = cur_node.nxt.nxt
            if cur_node.nxt:
                cur_node.nxt.prev = cur_node
            else:
                pokemon.tail = cur_node.nxt

    def swap_pokemon(first_node: DLLNode, second_node: DLLNode) -> None:
        """
        """
        '''temp = DLLNode(None)
        temp.prev = first_node.prev
        temp.nxt = first_node.nxt
        if first_node.prev:
            first_node.prev.nxt = second_node
        if first_node.nxt:
            first_node.nxt.prev = second_node
        first_node.prev = second_node.prev
        first_node.nxt = second_node.nxt

        if second_node.prev:
            second_node.prev.nxt = first_node
        if second_node.nxt:
            second_node.nxt.prev = first_node
        second_node.prev = temp.prev
        second_node.nxt = temp.nxt'''
        first_node.val, second_node.val = second_node.val, first_node.val

    for order in orders:
        if order[0] == "add":
            pos = int(order[1])
            cur = pokemon.head
            for i in range(0, pos):
                cur = cur.nxt

            add_pokemon(cur, order[2])

        elif order[0] == "remove":
            pos = int(order[1])
            cur = pokemon.head
            for i in range(0, pos):
                cur = cur.nxt

            remove_pokemon(cur)

        elif order[0] == "swap":
            pos1 = int(order[1])
            cur1 = pokemon.head.nxt
            for i in range(0, pos1):
                cur1 = cur1.nxt

            pos2 = int(order[2])
            cur2 = pokemon.head.nxt
            for i in range(0, pos2):
                cur2 = cur2.nxt

            swap_pokemon(cur1, cur2)

    return pokemon
