"""
Haoyun Wu
Coding Challenge 7
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from __future__ import annotations  # allow self-reference
from typing import List, Optional


class TreeNode:
    """Tree Node that contains a value as well as left and right pointers"""
    def __init__(self, val: int, left: TreeNode = None, right: TreeNode = None):
        self.val = val
        self.left = left
        self.right = right


def rewind_combo(points: List[int]) -> List[Optional[int]]:
    """
    In this problem you will be given a list of integers.
    Each element of the input list should be replaced with the greatest element
        that is smaller than the current element and is to its left.
    :param points: List[int]: Python integer list of size n representing hit points
    :return A new list with the greatest smaller predecessor for each element in the list
    """

    def insert(root, val):
        if root is None:
            return TreeNode(val)
        if root.val < val:
            root.right = insert(root.right, val)
        elif root.val > val:
            root.left = insert(root.left, val)
        return root

    def rewind_helper(root, n, largest=None):
        if root is None:
            return None
        if root.val < n:
            return rewind_helper(root.right, n, root.val)
        if root.val > n:
            return rewind_helper(root.left, n, largest)
        return largest

    node = TreeNode(points[0])
    for i in range(1, len(points)):
        node = insert(node, points[i])
    res = [rewind_helper(node, i) for i in points]
    return res
