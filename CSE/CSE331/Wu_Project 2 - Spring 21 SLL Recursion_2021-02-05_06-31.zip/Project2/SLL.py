"""
Project 1
CSE 331 S21 (Onsay)
Haoyun Wu
DLL.py
"""

from typing import TypeVar  # For use in type hinting
from Project2.Node import Node       # Import `Node` class

# Type Declarations
T = TypeVar('T')        # generic type
SLL = TypeVar('SLL')    # forward declared


class RecursiveSinglyLinkList:
    """
    Recursive implementation of an SLL
    """

    __slots__ = ['head']

    def __init__(self) -> None:
        """
        Initializes an `SLL`
        :return: None
        """
        self.head = None

    def __repr__(self) -> str:
        """
        Represents an `SLL` as a string
        """
        return self.to_string(self.head)

    def __str__(self) -> str:
        """
        Represents an `SLL` as a string
        """
        return self.to_string(self.head)

    def __eq__(self, other: SLL) -> bool:
        """
        Overloads `==` operator to compare SLLs
        :param other: right hand operand of `==`
        :return: `True` if equal, else `False`
        """
        comp = lambda n1, n2: n1 == n2 and (comp(n1.next, n2.next) if (n1 and n2) else True)
        return comp(self.head, other.head)

# ============ Modify below ============ #

    def to_string(self, curr: Node) -> str:
        """
        REPLACE - See Project 1
        Time complexity: O(n^2)
        """
        if curr is None:
            return 'None'
        if curr.next is None:
            return str(curr.val)
        return str(curr.val) + ' --> ' + str(self.to_string(curr.next))

    def length(self, curr: Node) -> int:
        """
        REPLACE
        Time complexity: O(n)
        """
        if curr is None:
            return 0
        if curr.next is None:
            return 1
        return 1 + self.length(curr.next)

    def sum_list(self, curr: Node) -> T:
        """
        REPLACE
        Time complexity: O(n)
        """
        if curr is None:
            return 0
        if curr.next is None:
            return curr.val
        return curr.val + self.sum_list(curr.next)

    def push(self, value: T) -> None:
        """
        REPLACE
        Time complexity: O(n)
        """

        def push_inner(curr: Node) -> None:
            """
            REPLACE
            Time complexity: O(n)
            """
            if curr.next is None:
                curr.next = node
            else:
                push_inner(curr.next)

        node = Node(value)
        if self.head is None:
            self.head = node
        else:
            push_inner(self.head)

    def remove(self, value: T) -> None:
        """
        REPLACE
        Time complexity: O(n)
        """

        def remove_inner(curr: Node) -> Node:
            """
            REPLACE
            Time complexity: O(n)
            """
            if curr.next is None:
                return
            if curr.next.val == value:
                if curr.next.next:
                    curr.next = curr.next.next
                else:
                    curr.next = None
            else:
                remove_inner(curr.next)

        if self.head is None:
            return
        if self.head.val == value:
            if self.head.next:
                self.head = self.head.next
            else:
                self.head = None
        else:
            remove_inner(self.head)

    def remove_all(self, value: T) -> None:
        """
        REPLACE
        Time complexity: O(n)
        """

        def remove_all_inner(curr):
            """
            REPLACE
            Time complexity: O(n)
            """
            if curr.next is None:
                return
            if curr.next.val == value:
                if curr.next.next:
                    curr.next = curr.next.next
                    remove_all_inner(curr)
                else:
                    curr.next = None
                    return
            remove_all_inner(curr.next)

        if self.head is None:
            return
        remove_all_inner(self.head)
        if self.head.val == value:
            self.head = self.head.next

    def search(self, value: T) -> bool:
        """
        REPLACE
        Time complexity: O(n)
        """

        def search_inner(curr):
            """
            REPLACE
            Time complexity: O(n)
            """

            if curr.next is None:
                return False
            if curr.next.val == value:
                return True
            return search_inner(curr.next)

        if self.head is None:
            return False
        if self.head.val == value:
            return True
        return search_inner(self.head)

    def count(self, value: T) -> int:
        """
        REPLACE
        Time complexity: O(n)
        """

        def count_inner(curr):
            """
            REPLACE
            Time complexity: O(n)
            """
            if curr.next is None:
                return 0
            if curr.next.val == value:
                return 1 + count_inner(curr.next)
            return count_inner(curr.next)

        if self.head is None:
            return 0
        res = count_inner(self.head)
        if self.head.val == value:
            res += 1
        return res

    def reverse(self, curr):
        """
        REPLACE
        Time complexity: O(n)
        """
        if curr is None:
            return None
        if curr.next is None:
            self.head = curr
            return curr
        head = self.reverse(curr.next)
        curr.next.next = curr
        curr.next = None
        return head


def crafting(recipe, pockets):
    """
    REPLACE
    Time complexity: O(rp)
    """
    if recipe.head is None:
        return False

    def create_copy(copy, curr):
        if curr:
            copy.push(curr.val)
            create_copy(copy, curr.next)

    def remove_pockets(curr):
        if curr:
            pockets.remove(curr.val)
        if curr.next:
            remove_pockets(curr.next)

    def check_pockets(curr):
        if curr is None:
            return True
        if not pockets_copy.search(curr.val):
            return False
        pockets_copy.remove(curr.val)
        return check_pockets(curr.next)

    pockets_copy = RecursiveSinglyLinkList()
    create_copy(pockets_copy, pockets.head)

    if check_pockets(recipe.head):
        remove_pockets(recipe.head)
        return True
    return False
