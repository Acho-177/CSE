"""
Name: Haoyun Wu
Coding Challenge 6
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
import queue


def gates_needed(departures, arrivals):
    """
    A function that finds the least number of gates
    /that need to be in use in order for the day’s airport operations to run smoothly.
    departures: List[float]: A python list of floats
        /containing departure times of flights at the airport
    arrivals: List[float]: A python list of floats
        /containing arrival times of flights at the airport
    Return: An integer
        /that represents the maximum number of gates needed
        /at any point during the day of these departures and arrivals
    """
    de_length = len(departures)
    ar_length = len(arrivals)
    if de_length == 0:
        return ar_length
    que = queue.Queue()
    res = 0
    i = j = 0

    while i < de_length:

        if j < ar_length:
            if departures[i] < arrivals[j]:
                que.get()
                i += 1
            elif departures[i] > arrivals[j]:
                que.put(1)
                j += 1
            else:
                i += 1
                j += 1
                continue
        else:
            que.get()
            i += 1

        if que.qsize() > res:
            res = que.qsize()

    if ar_length - j > res:
        res = que.qsize() + ar_length - j

    return res
