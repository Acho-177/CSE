"""
Haoyun Wu
Coding Challenge 8
CSE 331 Spring 2021
Professor Sebnem Onsay
"""

from typing import Set, Tuple, Dict
from CC8.InventoryItems import ItemInfo, ALL_ITEMS


class Bundle:
    """ Bundle Class """

    def __init__(self) -> None:
        """
        class member variable
        """
        self.data = ALL_ITEMS
        self.bundle = {}
        self.size = 0

    def to_set(self) -> Set[Tuple[str, int]]:
        """
        Converts the bundle to a set of tuples
            where the first index in the tuple is the item name
                  the second index is the amount of that item in the bundle.
        \return a set include all items
        """
        return set(self.bundle.items())

    def add_to_bundle(self, item_name: str, amount: int) -> bool:
        """
        Adds an amount of an item to the bundle if possible
        item_name: str: the name of the item to be added to the bundle
        amount: int: the amount of the itemName to be added to the bundle
        Return: a bool representing whether the add to the bundle was successful,
            True for added to the bundle, False for not added to the bundle
        """
        if self.data.items[item_name] and\
                self.size + amount / self.data.items[item_name].amount_in_stack <= 1:
            if self.bundle.get(item_name):
                self.bundle[item_name] += amount
            else:
                self.bundle[item_name] = amount
            self.size += amount / self.data.items[item_name].amount_in_stack
            return True
        return False

    def remove_from_bundle(self, item_name: str, amount: int) -> bool:
        """
        Removes an amount of an item from the bundle if possible
        item_name: str: the name of the item to be removed from the bundle
        amount: int: the amount of the itemName to be removed from the bundle
        Return: a bool representing whether the remove operation was successful,
            True for removed from the bundle,
            False for not removed/unable to removed from the bundle
        """
        if self.bundle.get(item_name):
            if self.bundle[item_name] < amount:
                return False
            if self.bundle[item_name] == amount:
                del self.bundle[item_name]
                self.size -= amount / self.data.items[item_name].amount_in_stack
            else:
                self.bundle[item_name] -= amount
                self.size -= amount / self.data.items[item_name].amount_in_stack
            return True
        return False
