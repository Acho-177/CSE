"""
Project 4
CSE 331 S21 (Onsay)
Haoyun Wu
CircularDeque.py
"""

from __future__ import annotations
from typing import TypeVar, List


# for more information on typehinting, check out https://docs.python.org/3/library/typing.html
T = TypeVar("T")                                # represents generic type

class CircularDeque:
    """
    Class representation of a Circular Deque
    """

    __slots__ = ['capacity', 'size', 'queue', 'front', 'back']

    def __init__(self, data: List[T] = [], capacity: int = 4):
        """
        Initializes an instance of a CircularDeque
        :param data: starting data to add to the deque, for testing purposes
        :param capacity: amount of space in the deque
        """
        self.capacity: int = capacity
        self.size: int = len(data)

        self.queue: list[T] = [None] * capacity
        self.front: int = None
        self.back: int = None

        for index, value in enumerate(data):
            self.queue[index] = value
            self.front = 0
            self.back = index

    def __str__(self) -> str:
        """
        Provides a string represenation of a CircularDeque
        :return: the instance as a string
        """
        if self.size == 0:
            return "CircularDeque <empty>"

        string = f"CircularDeque <{self.queue[self.front]}"
        current_index = self.front + 1 % self.capacity
        while current_index <= self.back:
            string += f", {self.queue[current_index]}"
            current_index = (current_index + 1) % self.capacity
        return string + ">"

    def __repr__(self) -> str:
        """
        Provides a string represenation of a CircularDeque
        :return: the instance as a string
        """
        return str(self)

    # ============ Modify below ============ #

    def __len__(self) -> int:
        """
        :return: the queue size
        """
        return self.size

    def is_empty(self) -> bool:
        """
        :return: if the queue is empty
        """
        return self.size == 0

    def front_element(self) -> T:
        """
        :return: the front element
        """
        if self.size == 0:
            return None
        return self.queue[self.front]

    def back_element(self) -> T:
        """
        :return: the back element
        """
        if self.size == 0:
            return None
        return self.queue[self.back]

    def front_enqueue(self, value: T) -> None:
        """
        insert in front
        :return: None
        """
        if self.size == 0:
            self.front = self.back = 0
            self.queue[0] = value
            self.size += 1
        else:
            self.front = (self.front - 1) % self.capacity
            self.queue[self.front] = value
            self.size += 1
        self.grow()

    def back_enqueue(self, value: T) -> None:
        """
        insert in back
        :return: None
        """
        if self.size == 0:
            self.front = self.back = 0
            self.queue[0] = value
            self.size += 1
        else:
            self.back = (self.back + 1) % self.capacity
            self.queue[self.back] = value
            self.size += 1
        self.grow()

    def front_dequeue(self) -> T:
        """
        delete the front element
        :return: the first element
        """
        if self.size == 0:
            return None
        res = self.queue[self.front]
        self.queue[self.front] = None
        self.size -= 1
        self.front = (self.front + 1) % self.capacity
        self.shrink()
        return res

    def back_dequeue(self) -> T:
        """
        delete the back element
        :return: the last element
        """
        if self.size == 0:
            return None
        res = self.queue[self.back]
        self.queue[self.back] = None
        self.size -= 1
        self.back = (self.back - 1) % self.capacity
        self.shrink()
        return res

    def grow(self) -> None:
        """
        increase the capacity
        """
        if self.size == self.capacity:
            self.capacity *= 2
            copy = self.queue
            self.queue = [None] * self.capacity
            i = 0
            pos = self.front
            for i in range(self.size):
                self.queue[i] = copy[pos]
                pos = (1+pos) % len(copy)
            self.front = 0
            self.back = self.size - 1

    def shrink(self) -> None:
        """
        shrink the capacity
        """
        if self.size <= self.capacity // 4 and self.capacity // 2 >= 4:
            self.capacity //= 2
            copy = self.queue
            self.queue = [None] * self.capacity
            i = 0
            pos = self.front
            for i in range(self.size):
                self.queue[i] = copy[pos]
                pos = (1+pos) % len(copy)
            self.front = 0
            self.back = self.size - 1


def LetsPassTrains102(infix: str):
    """
    application
    :return: a transformed string
    """
    if infix == "":
        return [0, ""]

    def calculate_post(inputs: str):

        inputs = inputs.replace("(", "( ")
        inputs = inputs.replace(")", " )")

        op_priority = dict()
        op_priority["^"] = 4
        op_priority["*"] = 3
        op_priority["/"] = 3
        op_priority["+"] = 2
        op_priority["-"] = 2
        op_priority["("] = 1
        op = CircularDeque()
        res = []
        tokens = inputs.rsplit()

        for token in tokens:
            if token not in "+-*/()^":
                res.append(token)
            elif token == '(':
                op.back_enqueue(token)
            elif token == ')':
                back = op.back_dequeue()
                while back != '(':
                    res.append(back)
                    back = op.back_dequeue()
            else:
                while (not op.is_empty()) and \
                        (op_priority[op.back_element()] >= op_priority[token]):
                    res.append(op.back_dequeue())
                op.back_enqueue(token)

        while not op.is_empty():
            res.append(op.back_dequeue())

        postfix = " ".join(res)
        return postfix

    def calculate_eval(inputs):

        cd_op = CircularDeque()
        data = inputs.rsplit()

        if len(data) == 1:
            return float(data[0])

        for val in data:
            if val not in "+-*/()^":
                cd_op.back_enqueue(val)
                continue

            op1 = cd_op.back_dequeue()
            op2 = cd_op.back_dequeue()

            if val == '+':
                cd_op.back_enqueue(float(op2) + float(op1))
            elif val == '-':
                cd_op.back_enqueue(float(op2) - float(op1))
            elif val == '*':
                cd_op.back_enqueue(float(op2) * float(op1))
            elif val == '/':
                cd_op.back_enqueue(float(op2) / float(op1))
            elif val == '^':
                cd_op.back_enqueue(float(op2) ** float(op1))

        return cd_op.back_element()

    post = calculate_post(infix)
    infix = infix.replace(" - - ", " + ")
    postfixforeval = calculate_post(infix)
    eval_res = calculate_eval(postfixforeval)
    return [eval_res, post]
