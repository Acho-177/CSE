#include "decoder.h"
#include <string.h>
#include <stdio.h>
void setBit(char *decoded, int *bit)
{
  decoded[*bit/8] |= 1 << (7-(*bit)%8);
  (*bit)++;
}
/**
 * Decode an encoded string into a character stream.
 * @param encoded The input string we are decoding
 * @param decoded The output string we produce
 * @param maxLen The maximum size for decoded
 */
void decoder(const char *encoded, char *decoded, int maxLen)
{
    // This is just a copy so it has something in decoded
    int i = 0;  
    for (i = 0; i < maxLen; i++)
    {
      decoded[i] = 0;
    }
    int bit = 0;
    for (; *encoded; encoded++)
    {
      switch(*encoded)
      {
        case '+':
          bit+=3;
          break;
        case 'A':
          bit+=2;
          setBit(decoded, &bit);
          break;
        case '!':
          bit++;
          setBit(decoded, &bit);
          bit++;
          break;
        case 's':
          bit++;
          setBit(decoded, &bit);
          setBit(decoded, &bit);
          break;
        case 'n':
          setBit(decoded, &bit);
          bit+=2;
          break;
        case 'd':
          setBit(decoded, &bit);
          bit++;
          setBit(decoded, &bit);
          break;
        case '#':
          setBit(decoded, &bit);
          setBit(decoded, &bit);
          bit++;
          break;
        case '7':
          setBit(decoded, &bit);
          setBit(decoded, &bit);
          setBit(decoded, &bit);
          break;
        case 'g':
          bit+=2;
          break;
        case '%':
          bit++;
          setBit(decoded, &bit);
          break;
        case 'r':
          setBit(decoded, &bit);
          bit++;
          break;
        case 'c':
          setBit(decoded, &bit);
          setBit(decoded, &bit);
          break;
      }

    }
       
   // strncpy(decoded, encoded, maxLen);
}

