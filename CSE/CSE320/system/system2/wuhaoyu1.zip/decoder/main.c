/**
 * Main program for testing the decoder
 */
#include <stdio.h>
#include "decoder.h"

/*
 * Main
 */
int main()
{
 // const char *encoded="fill in your version here";
     const char *encoded="\
                          !%ggcd%%drdrg%s%#A+gsgrrcr%g7gncs#7A+rg+cd#c%cddc+n7sdgAg+sr\
                          s%c%gs%cdc++ngAd+%dAss%gr7+nggnr+#%!%A#7g#%ggArnAnAsgngrgg%7\
                          gdnrr#+r7grsr%r%g+sd+#7r%g+%d+%rr%%nn%r%!%s+!g++#nA%g7%gsscg\
                          n+sr+%drAr7d#r+rg+crns%gArr!crsAg+sgn%rg!c%rdd#%r+rc+ncsgsgr\
                          nngg7%+#r+#nrc%#sg7gdcg!g+nng#!r!%c%cAr%gggc+#c%cddd%#+%nrrc\
                          %rArc+#nrcsr%n7A+g%rngc%A%dd%#s%r!rcsg%r%rgrg++#nA!%c!g#7r%+\
                          g%rsAr7rcs+csg%r7d#cnrg+#%%%cnAngdnssrrgcs+7r!%ggA#ns%ggcA%g\
                          rg+cgss%n%nAsr%rcr%ddA%rAnrg+cgrAr!r#+d#ns!gA++cng%r+r7!g7!g\
                          cA!7AArcrgrggs%cr#sg!+g7!gc!g%r!nngggs%+!nrAcAAcsdg%nA%n%r#r\
                          +!7g%+g!%A%#ngr%#cr%r!g+cd+c!+cgrnrg+7+g7ArccA%rgc%rng#r!c+c\
                          Ag+%n#%rc#cr%An%dr!r!+A#rgc%gg#+r7%ggr+gc%gArccssg%r!gcrsgn+\
                          %c%gs%ggcgrr%g+s%d%ngr#7g%++g%rngdAc!g#cc%rsrcA%%c%g%rngcA%s\
                          nrA%rg!+gcrn%rnAdgdcg#!+Add%r+r#cr%dgrc+!#gc%rg%%rcggngg7+Ac\
                          Agcgrr#g#c!!7gcs%gdd7%d#A%#grgg%Agr#%n%g+%csdndgr+Ans%d7%#ds\
                          s+#%ggn+%d%A#rdcAd#rg%gg+g#r+rn7!ArnAcgr%rcc%csnrggs%gdc!g%g\
                          gg#c##%r%nc+dr+r+Adgrc%#%c!gcgrdcgr%#!%c!r7ggsdggn+srns!gsA!\
                          !+gcg%r7nrc+c%dnsA%grc+%ggg7!Arrgsgrdr7+ngAdgAr%%A+gs%rrc!!c\
                          gcdrr+7%+!+gc+rsgdA+++#r+rncnc%c!Ad7%#ggcn+cA%sA+%++#gn7nnng\
                          Arngc%gd#sA++c%7sr7ssrgr+Adgrcsn#sg##gcA%s#+c%gdn%g##g#!nn+%\
                          cAr7!g#g!c%cg#!AnA%#!%r%g%#sA%c+";
  char decoded[1000];

  decoder(encoded, decoded, sizeof(decoded));
  printf("%s\n", decoded);

  return 0;
}

