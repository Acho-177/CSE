#include <stdlib.h>
#include <string.h>
#include "binarymath.h"


char *copy_string(const char *str)
{
  size_t required = strlen(str) + 1;
  char *result = (char *)malloc(required);
  strncpy(result, str, required);
  result[required-1] = '\0';
  return result;
}

/**
 * Increment a BINARY_SIZE binary number expressed as a 
 * character string.
 * @param number The number we are passed
 * @returns Incremented version of the number
 */
char *inc(const char *number)
{
    char *copy_num = copy_string(number);

    int i = 99;
    //plus 1 when the end is 0
    if (copy_num[i] == '0')
    {
      copy_num[i] = '1';
    }  
    else
    {
      //process untill meet 0
      while(copy_num[i] == '1')
      {
        copy_num[i] = '0';
        i--;
      }
      copy_num[i] = '1';
    }
    
    return copy_num;
}


/**
 * Negate a BINARY_SIZE binary number expressed as a character string
 * @param number The number we are passed
 * @returns Incremented version of the number
 */
char *negate(const char *number)
{
  char *copy_num = copy_string(number);
  int i = 0;
  for (; i<=99; i++)
  {
    copy_num[i] = number[i] == '0' ? '1':'0';
  }
  char *res = inc(copy_num);
  free(copy_num);  
  return res;
}

/**
 * Add two BINARY_SIZE binary numbers expressed as
 * a character string. 
 * @param a First number to add
 * @param b Second number to add
 * @return a + b
 */
char *add(const char *a, const char *b)
{
  char *res = copy_string(a);
   
  int ex = 0;
  int i = 99;

  for (; i>=0; i--)
  {
    if (ex == 0)
    {
      if (a[i] == '1' && b[i] == '1')
      {
        ex = 1;
        res[i] = '0';
      }
      else if (a[i] == '0' &&  b[i] == '0')
      {
        ex = 0;
        res[i] = '0';
      }
      else
      {
        ex = 0;
        res[i] = '1';
      } 
    }
    else
    {
      if (a[i] == '0' && b[i] == '0')
      {
        ex = 0;
        res[i] = '1';
      } 
      else
      {
        if (a[i] == '1' &&  b[i] == '1')
          res[i] = '1';    
        else
          res[i] = '0';
        ex = 1;
      }
    }
  }

  return res;
}

/**
 * Subtract two BINARY_SIZE binary numbers expressed as
 * a character string.
 * @param a First number
 * @param b Second number 
 * @return a - b
 */
char *sub(const char *a, const char *b)
{  
  //a-b equal to a+(-b) 
    char *negate_b = negate(b);
    char *res = add(a,negate_b);
    free(negate_b);
    return res;
}

