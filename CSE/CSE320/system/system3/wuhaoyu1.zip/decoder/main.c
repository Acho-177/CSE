#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *copy_string(const char *str)
{
  size_t required = strlen(str) + 1;
  char *result = (char *)malloc(required);
  strncpy(result, str, required);
  result[required-1] = '\0';
  return result;
}

void free_strings(char **strings)
{
  int length = 0;
  for(; strings[length]; length++)
    free(strings[length]);
//  free(strings); 
}

char *xor(const char *key, const char *line)
{
  size_t len = strlen(key) - 1;
  char *res = copy_string(key);

  int i = 0;
  for (; i < len; i++)
  {
    res[i] = key[i] == line[i] ? '0' : '1';
  }
   
  return res;
}

char *rol(const char *line, int num)
{
  char *res = copy_string(line);
  int i = 0;
  int j = num;
  //copy the digits being roled
  for (; j < strlen(line)-1 ; j++, i++)
    res[i] = line[j];
  int k = 0;
  //copy the rest digits
  for (; k <num; k++,i++)
    res[i] = line[k];
  return res;
}

void print_line(const char *line)
{
  int i=0;
  for (; i < strlen(line)-1; i++)
  {
    if (line[i] == '0') printf(" ");
    else printf("X");
  }
  printf("\n");
}

int main(int argc, char *argv[])
{
  if (argc < 2)
  {
    printf("Usage: decoder file\n");
    return 1;
  }

   FILE *fp = fopen(argv[1], "r");
   if (fp == NULL)
   {
     printf("Unable to open input file\n");
     return 1;
   }
   
   char buffer[1000];
   int is_first_line = 1; 
   int line_num = 0;
   char *key; 
   char *line;
   char *decoded_line;
   char *res;
   char *lines[1000];  

   while(fgets(buffer, sizeof(buffer), fp) != NULL) 
   {
      if (is_first_line == 1)
      {
          //save the keu which is used to decode the lines
        key = copy_string(buffer);
        is_first_line = 0;
   //     printf("the key: %s \n",key);
      }
      else
      {
        line = copy_string(buffer);
   //     printf("current line: %s", line);
        decoded_line = xor(key,line);
   //    printf("decoded line: %s",decoded_line);
        res = rol(decoded_line, line_num);
   //     printf("res         : %s",res);
        
        lines[line_num] = res;
    
        line_num++;
    
        free(line);
        free(decoded_line);
   //   free(res);

      }
   }
    
  //print the lines reversely  
   int i=line_num-1;
   for (; i>=0; i--)
     print_line(lines[i]);  
  
   free(key);
   free_strings(lines);  
   fclose(fp);    
   return 1;      
}
